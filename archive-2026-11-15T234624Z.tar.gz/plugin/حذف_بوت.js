import { deleteSubBot, resolveSubBotNumber } from '../BG/subbots.js'

export default {
  command: ['حذف_بوت', 'حذفبوت', 'delbot'],
  category: 'إدارة البوتات',
  description: 'حذف جلسة بوت فرعي (بالـ LID أو الرقم)',
  dev: true,

  async run({ sock, args, reply, prefix }) {
    // يقبل: .حذف_بوت 151780386173139@lid   أو   .حذف_بوت 201234567890   (ومعها كلمة "بوت" اختياري)
    const input = args.join('').replace(/\D/g, '')
    if (!/^\d{7,20}$/.test(input)) {
      return reply(
        'طريقة الاستخدام:\n' +
        `\`${prefix}حذف_بوت <LID>\`\n\n` +
        'الـ LID تشوفه في قائمة `.بوتات`. يفصل الجهاز ويحذف جلسة البوت الفرعي.',
      )
    }

    const number = resolveSubBotNumber(input)
    if (!number) return reply('ما لقيت بوت فرعي بهذا المعرّف.')

    // لو الأمر واصل من نفس البوت اللي بينحذف، نرد قبل الحذف (بعده الاتصال يتقفل)
    const selfDelete = sock?.isSubBot && sock.subbotNumber === number

    try {
      if (selfDelete) await reply('جاري حذف جلسة هذا البوت وفصل الجهاز...').catch(() => {})
      const result = await deleteSubBot(number)
      if (selfDelete) return
      return await reply(result
        ? `تم حذف جلسة البوت الفرعي${result.lid ? ` (${result.lid})` : ''}.`
        : 'ما لقيت بوت فرعي بهذا المعرّف.')
    } catch (error) {
      if (selfDelete) return
      return reply(`تعذر الحذف:\n${error.message}`)
    }
  },
}
