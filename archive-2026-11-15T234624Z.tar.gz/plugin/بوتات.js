import { getSubBotStats, getSubBotList } from '../BG/subbots.js'

function duration(ms) {
  const seconds = Math.floor(ms / 1000)
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const rest = seconds % 60
  return [days && `${days}d`, `${hours}h`, `${minutes}m`, `${rest}s`]
    .filter(Boolean)
    .join(' ')
}

export default {
  command: ['بوتات', 'البوتات', 'قائمة_البوتات', 'bots'],
  category: 'إدارة البوتات',
  dev: true,

  async run({ reply }) {
    const stats = getSubBotStats()
    const rows = getSubBotList().map((bot, index) => {
      const name = bot.name || 'غير معروف'
      return `${index + 1}. ${bot.lid || 'LID غير معروف'}\n   الاسم: ${name}\n   التشغيل: ${duration(Date.now() - bot.connectedAt)}`
    })

    const message = [
      'قائمة البوتات الفرعية',
      `الاتصالات النشطة: ${stats.active}/${stats.limit}`,
      `الجلسات المحفوظة: ${stats.configured}`,
      '',
      ...(rows.length ? rows : ['لا توجد اتصالات فرعية نشطة حالياً']),
    ].join('\n')

    return reply(message)
  },
}
