import { startSubBot } from '../BG/subbots.js'
import { parsePhone } from '../BG/BMG/phone.js'

export default {
  command: ['تنصيب', 'jadibot'],
  category: 'إدارة البوتات',
  dev: true,

  async run({ sock, m, args, from, reply }) {
    const parsed = parsePhone(args)
    if (!parsed.ok) return reply(parsed.error)
    const number = parsed.number

    // نتأكد من واتساب نفسه إن الرقم مسجّل (لو تعذر الفحص نكمل ونعتمد على فحص الصيغة)
    try {
      const res = await Promise.race([
        sock.onWhatsApp(`${number}@s.whatsapp.net`),
        new Promise(resolve => setTimeout(() => resolve(undefined), 8000)),
      ])
      const notRegistered = Array.isArray(res) && (res.length === 0 || res[0]?.exists === false)
      if (notRegistered) return reply('هذا الرقم غير مسجّل على واتساب. تأكد من الرقم وكود الدولة.')
    } catch { /* تعذر الفحص: نكمل */ }

    try {
      await startSubBot(number, {
        parentSock: sock,
        notifyJid: from,
        quoted: m,
        requestPairing: true,
      })
      return await reply(`تم تجهيز جلسة البوت الفرعي.\nسيصلك كود الربط بعد لحظات.`)
    } catch (error) {
      return await reply(`تعذر بدء التنصيب:\n${error.message}`)
    }
  },
}
