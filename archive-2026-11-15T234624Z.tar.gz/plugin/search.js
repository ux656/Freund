import { ytSearch, ytInfo, pickVideoSource, sendVideo, fmtBytes, fmtTime } from '../BG/BMG/downloader.js'
import ui from '../BG/BMG/ui.js'

// آخر نتايج لكل شات، عشان ينفع بعدها تختار برقم
const cache = new Map() // from -> { at, results }
const TTL = 10 * 60 * 1000

const setResults = (from, results) => {
  cache.set(from, { at: Date.now(), results })
  if (cache.size > 200) cache.delete(cache.keys().next().value)
}

const getResults = from => {
  const c = cache.get(from)
  if (!c || Date.now() - c.at > TTL) {
    cache.delete(from)
    return null
  }
  return c.results
}

export default {
  command: ['بحث', 'ytsearch', 'youtube'],
  description: 'بحث في يوتيوب — وبعدين اختار النتيجة برقم للتحميل',
  category: 'وسائط',
  handler: async (sock, mek, { from, q, prefix, reply }) => {
    const raw = String(q || '').trim()

    // اختيار نتيجة من آخر بحث
    if (/^\d+$/.test(raw)) {
      const saved = getResults(from)
      if (!saved) return reply(ui.warn(`مفيش بحث محفوظ — اكتب الأول ${prefix}بحث وأي كلمات`))
      const hit = saved[Number(raw) - 1]
      if (!hit) return reply(ui.err(`الرقم ده مش في القائمة، اختار من 1 لـ ${saved.length}`))
      await reply(ui.info(`⏳ جاري تجيب «${hit.title}»...`))
      const info = await ytInfo(hit.id)
      const src = pickVideoSource(info)
      if (!src) throw new Error('مفيش نسخة متاحة للتحميل — جرّب أمر الصوت')
      return sendVideo(sock, from, src.url, [
        `🎬 ${info.title}`,
        `👤 ${info.author}`,
        `⏱️ ${fmtTime(info.durationSec)} • 📦 ${fmtBytes(src.size)}`,
      ].join('\n'), mek)
    }

    if (!raw) {
      const saved = getResults(from)
      return reply(ui.box('بحث يوتيوب', [
        'اكتب بعد الأمر اسم أي فيديو',
        `وبعدين اختار برقم من 1 لـ${saved?.length ? ' ' + saved.length : ' 10'}`,
        `مثال: ${prefix}بحث أغاني 2026`,
      ]))
    }

    const results = await ytSearch(raw)
    setResults(from, results)
    const rows = results.map((r, i) => `${i + 1}. ${r.title}${r.time ? ` [${r.time}]` : ''}`)
    return reply(ui.box(`نتايج «${raw}»`, rows))
  },
}
