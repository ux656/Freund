export default {
  command: ['تست', 'test'],
  description: 'اختبار استجابة البوت',
  category: 'عام',
  handler: async (sock, mek, { reply, ui }) => {
    const t = Number(mek.messageTimestamp?.low ?? mek.messageTimestamp ?? 0)
    const delay = t ? Math.max(0, Date.now() - t * 1000) : 0
    const up = Math.floor(process.uptime())
    const mem = (process.memoryUsage().rss / 1024 / 1024).toFixed(0)
    const botType = sock.isSubBot ? `بوت فرعي (${sock.subbotNumber || 'غير معروف'})` : 'بوت أساسي'
    await reply(ui.box('البوت شغال', [
      `النوع: ${botType}`,
      `الاسم: ${ui.name}`,
      `التأخير: ${delay}ms`,
      `مدة التشغيل: ${Math.floor(up / 3600)}س ${Math.floor((up % 3600) / 60)}د ${up % 60}ث`,
      `الذاكرة: ${mem}MB`,
    ]))
  },
}
