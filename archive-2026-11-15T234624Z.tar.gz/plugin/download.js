import {
  detectUrl, detectPlatform, ytInfo, pickVideoSource, pickAudioSource,
  tiktokInfo, sendVideo, sendAudio, sendImage, fmtBytes, fmtTime,
} from '../BG/BMG/downloader.js'
import ui from '../BG/BMG/ui.js'

const AUDIO_CMDS = ['صوت', 'song', 'audio', 'اغنيه']
const TIK_CMDS = ['تك', 'tiktok']
const QUALITIES = [144, 240, 360, 480, 720, 1080]

async function ytPath(sock, mek, from, target, isAudio, quality, reply) {
  const info = await ytInfo(target)
  if (isAudio) {
    const src = pickAudioSource(info)
    if (!src) throw new Error('مفيش مقطع صوتي متاح للفيديو ده')
    await reply(ui.info(`⏳ جاري تحميل الصوت (${fmtBytes(src.size)})...`))
    return sendAudio(sock, from, src.url, '', mek, { mimetype: src.mime || 'audio/mpeg' })
  }
  // لو الجودة المطلوبة مش موجودة بنجرب أي نسخة متكاملة
  let src = pickVideoSource(info, quality)
  if (!src?.combined) src = pickVideoSource(info, 0)
  if (!src?.combined) throw new Error('مفيش نسخة بالصوت متاحة دلوقتي — جرّب أمر الصوت')
  await reply(ui.info(`⏳ جاري تحميل الفيديو (${fmtBytes(src.size)})...`))
  return sendVideo(sock, from, src.url, [
    `🎬 ${info.title}`,
    `👤 ${info.author} • ⏱️ ${fmtTime(info.durationSec)}`,
    `🎚️ ${src.quality || `${src.height || 0}p`} • 📦 ${fmtBytes(src.size)}`,
  ].join('\n'), mek)
}

async function tikPath(sock, mek, from, url, isAudio, reply) {
  const t = await tiktokInfo(url)
  const cap = [
    `🎵 ${t.title}`,
    `👤 ${t.author}`,
    t.durationSec ? `⏱️ ${fmtTime(t.durationSec)}` : '',
  ].filter(Boolean).join('\n')
  if (isAudio && t.audio) return sendAudio(sock, from, t.audio, '', mek)
  if (t.video) return sendVideo(sock, from, t.video, cap, mek)
  if (t.images.length) {
    for (const [i, img] of t.images.slice(0, 10).entries()) {
      await sendImage(sock, from, img, i === 0 ? cap : '', mek)
    }
    if (t.audio) await sendAudio(sock, from, t.audio, '', mek)
    return
  }
  throw new Error('مفيش محتوى قابل للتحميل في الرابط ده')
}

export default {
  command: ['فيديو', 'yt', 'تنزيل', 'صوت', 'song', 'audio', 'اغنيه', 'تك', 'tiktok'],
  description: 'تحميل فيديو أو صوت من يوتيوب وتيك توك — برابط أو اسم الفيديو',
  category: 'وسائط',
  handler: async (sock, mek, { from, q, args, command, reply }) => {
    const cmd = String(command || '').toLowerCase()
    const raw = String(q || '').trim()
    const isAudio = AUDIO_CMDS.includes(cmd)
    const isTikOnly = TIK_CMDS.includes(cmd)

    if (!raw) {
      return reply(ui.box('طريقة الاستخدام', [
        'فيديو <رابط يوتيوب أو اسم الفيديو>',
        'فيديو <اسم> 720 — لجودة معينة',
        'صوت <رابط أو اسم الفيديو> — للصوت بس',
        'تك <رابط تيك توك> — فيديو بدون علامة مائية',
      ]))
    }

    // رقم الجودة لو المستخدم كتبه (مثال: فيديو اسم الفيديو 720)
    let quality = 0
    for (const a of args || []) {
      const n = Number(String(a).replace(/\D/g, ''))
      if (QUALITIES.includes(n)) quality = n
    }

    // نص البحث من غير الرابط وغير رقم الجودة
    const url = detectUrl(raw)
    const query = (url ? raw.split(url).join(' ') : raw)
      .split(/\s+/)
      .filter(w => w && !QUALITIES.includes(Number(w.replace(/\D/g, ''))))
      .filter(w => w !== String(quality))
      .join(' ')
      .trim()

    if (url) {
      const platform = detectPlatform(url)
      if (!platform) return reply(ui.err('الرابط ده مش مدعوم — مدعوم حالياً: يوتيوب و تيك توك'))
      if (platform === 'youtube') return ytPath(sock, mek, from, url, isAudio, quality, reply)
      return tikPath(sock, mek, from, url, isAudio, reply)
    }

    if (isTikOnly) return reply(ui.warn('اكتب رابط تيك توك مع الأمر'))
    if (!query) return reply(ui.warn('اكتب اسم الفيديو أو رابطه بعد الأمر'))
    return ytPath(sock, mek, from, query, isAudio, quality, reply)
  },
}
