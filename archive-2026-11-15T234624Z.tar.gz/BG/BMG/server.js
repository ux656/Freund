import crypto from 'node:crypto'
import config from '../config.js'
import { log } from './logger.js'
import { startSubBot } from '../subbots.js'

const state = { status: 'starting', startedAt: Date.now(), me: null }
const installSessions = new Map()
let parentSock = null
const INSTALL_TTL = 60_000
const SESSION_RETENTION = 5 * 60_000

export const setStatus = (status, me = null) => {
  state.status = status
  if (me) state.me = me
}

export function setParentSocket(sock) {
  parentSock = sock || null
}

const READY_STATUSES = new Set(['open', 'ready', 'connected'])
const isReady = () => READY_STATUSES.has(String(state.status).toLowerCase())

function buildInfo() {
  return {
    bot: config.botName,
    status: state.status,
    connectedAs: state.me,
    uptime: Math.floor(process.uptime()),
    startedAt: state.startedAt,
    memoryMB: Math.round(process.memoryUsage().rss / 1048576),
    node: process.version,
  }
}

function safeEqual(a, b) {
  const left = Buffer.from(String(a || ''))
  const right = Buffer.from(String(b || ''))
  return left.length === right.length && crypto.timingSafeEqual(left, right)
}

function requireApiToken(req, res, next) {
  const expected = process.env.BOT_API_TOKEN
  const supplied = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (!expected || !safeEqual(supplied, expected)) {
    return res.status(401).json({ error: 'unauthorized' })
  }
  next()
}

function pruneInstallSessions() {
  const now = Date.now()
  for (const [id, item] of installSessions) {
    if (now - item.updatedAt > SESSION_RETENTION || item.status === 'linked' && now - item.updatedAt > SESSION_RETENTION) {
      installSessions.delete(id)
    }
  }
}

const notFoundHandler = (_req, res) => res.status(404).json({ error: 'not found' })
const errorHandler = (err, _req, res, _next) => {
  log.error(`http: ${err.message}`)
  if (!res.headersSent) res.status(500).json({ error: 'internal error' })
}

export async function startServer() {
  const cfg = config.server || {}
  if (cfg.enabled === false) return null
  let express
  try { ;({ default: express } = await import('express')) }
  catch (e) {
    const reason = e.code === 'ERR_MODULE_NOT_FOUND' ? 'run npm install' : e.message
    log.warn(`status server disabled (${reason})`)
    return null
  }

  const app = express()
  app.disable('x-powered-by')
  app.use(express.json({ limit: '8kb' }))

  app.get('/', (_req, res) => res.json(buildInfo()))
  app.get('/health', (_req, res) => res.status(isReady() ? 200 : 503).json(buildInfo()))

  // These endpoints are server-to-server only. Never call them from browser code.
  app.post('/api/install', requireApiToken, async (req, res, next) => {
    try {
      pruneInstallSessions()
      if (!isReady() || !parentSock) return res.status(503).json({ error: 'main_bot_not_ready' })
      const phone = String(req.body?.phone || '').replace(/\D/g, '')
      if (!/^\d{7,15}$/.test(phone)) return res.status(400).json({ error: 'invalid_phone' })
      const id = crypto.randomUUID()
      const item = { id, phone, status: 'starting', code: null, createdAt: Date.now(), updatedAt: Date.now(), expiresAt: Date.now() + INSTALL_TTL, error: null }
      installSessions.set(id, item)
      try {
        await startSubBot(phone, {
          parentSock,
          requestPairing: true,
          onPairingCode: (code, expiresAt) => {
            item.code = code
            item.status = 'code_ready'
            item.expiresAt = Math.min(expiresAt || Date.now() + INSTALL_TTL, Date.now() + INSTALL_TTL)
            item.updatedAt = Date.now()
          },
          onPairingError: error => {
            item.status = 'failed'
            item.error = String(error?.message || 'pairing_failed').slice(0, 240)
            item.updatedAt = Date.now()
          },
          onStatus: status => {
            item.status = status === 'linked' ? 'linked' : status
            item.code = null
            item.updatedAt = Date.now()
          },
        })
      } catch (error) {
        item.status = 'failed'
        item.error = String(error?.message || 'install_failed').slice(0, 240)
        item.updatedAt = Date.now()
      }
      res.status(item.status === 'failed' ? 400 : 202).json({
        sessionId: id,
        status: item.status,
        code: item.code,
        expiresAt: item.expiresAt,
        serverTime: Date.now(),
        error: item.error,
      })
    } catch (error) { next(error) }
  })

  app.get('/api/install/:id', requireApiToken, (req, res) => {
    pruneInstallSessions()
    const item = installSessions.get(String(req.params.id || ''))
    if (!item) return res.status(404).json({ error: 'session_not_found', serverTime: Date.now() })
    if (item.status !== 'linked' && item.status !== 'failed' && Date.now() >= item.expiresAt) {
      item.status = 'expired'
      item.code = null
      item.updatedAt = Date.now()
    }
    res.json({
      sessionId: item.id,
      status: item.status,
      code: item.code,
      expiresAt: item.expiresAt,
      serverTime: Date.now(),
      error: item.error,
    })
  })

  app.use(notFoundHandler)
  app.use(errorHandler)

  const port = Number(process.env.PORT || cfg.port || 24707)
  const host = cfg.host || '0.0.0.0'
  return await new Promise(resolve => {
    const server = app.listen(port, host, () => {
      log.info(`status/install server on http://${host}:${port}`)
      resolve(server)
    })
    server.once('error', e => {
      log.warn(e.code === 'EADDRINUSE' ? `status server: port ${port} is already in use` : `status server not started: ${e.message}`)
      resolve(null)
    })
  })
}
