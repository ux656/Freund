import { log } from './logger.js'

// ─────────────────────────────────────────────────────────────
//  أحداث القروبات (groups.upsert / groups.update / group-participants.update)
//  + كاش لبيانات القروبات يُمرَّر لـ Baileys عبر cachedGroupMetadata
//  (يقلل طلبات الشبكة عند الإرسال للقروبات ويقلل خطر الـ rate-limit)
// ─────────────────────────────────────────────────────────────

const TTL = 10 * 60_000   // الكاش يُنسى بعد 10 دقايق
const MAX = 300           // أقصى عدد قروبات بالكاش لكل بوت (الأقدم يُحذف)

export function createGroupCache() {
  const map = new Map() // jid -> { meta, at }

  const get = jid => {
    const hit = map.get(jid)
    if (!hit) return undefined
    if (Date.now() - hit.at > TTL) {
      map.delete(jid)
      return undefined
    }
    return hit.meta
  }

  const set = (jid, meta) => {
    map.delete(jid)
    map.set(jid, { meta, at: Date.now() })
    while (map.size > MAX) map.delete(map.keys().next().value)
  }

  const del = jid => map.delete(jid)

  return { get, set, del, clear: () => map.clear(), get size() { return map.size } }
}

const pid = p => (typeof p === 'string' ? p : p?.id || p?.lid || p?.phoneNumber || '')

const sameParticipant = (a, b) => {
  const ids = new Set([a?.id, a?.lid, a?.phoneNumber].filter(Boolean))
  return [b?.id, b?.lid, b?.phoneNumber].some(x => x && ids.has(x))
}

/** يطبّق تغيير الأعضاء على نسخة الكاش. لو ما قدرنا نحدّثها بثقة، نحذفها ونخلي Baileys يجيبها من جديد. */
function applyParticipantsChange(cache, id, action, participants) {
  const cur = cache.get(id)
  if (!cur) return
  if (!Array.isArray(cur.participants)) return cache.del(id)

  const targets = (participants || []).map(p => (typeof p === 'string' ? { id: p } : p)).filter(p => pid(p))
  let list = cur.participants

  switch (action) {
    case 'add':
      for (const t of targets) {
        if (!list.some(p => sameParticipant(p, t))) list = [...list, { ...t, admin: t.admin ?? null }]
      }
      break
    case 'remove':
      list = list.filter(p => !targets.some(t => sameParticipant(p, t)))
      break
    case 'promote':
    case 'demote':
      list = list.map(p => (targets.some(t => sameParticipant(p, t))
        ? { ...p, admin: action === 'promote' ? 'admin' : null }
        : p))
      break
    default:
      return cache.del(id) // modify / approve / غيره: نعيد الجلب
  }

  cache.set(id, { ...cur, participants: list, size: list.length })
}

/**
 * يربط مستمعات أحداث القروبات بسوكيت.
 * dispatch(eventName, data) تُستدعى بعد تحديث الكاش (لتمرير الحدث للإضافات).
 */
export function attachGroupEvents(sock, cache, { label = 'bot', dispatch } = {}) {
  const emit = (event, data) => {
    if (!dispatch) return
    Promise.resolve(dispatch(event, data)).catch(error =>
      log.error(`${label}: ${event} handler: ${error?.message || error}`),
    )
  }

  sock.ev.on('groups.upsert', groups => {
    for (const g of groups || []) if (g?.id) cache.set(g.id, g)
    emit('groups.upsert', groups)
  })

  sock.ev.on('groups.update', updates => {
    for (const u of updates || []) {
      if (!u?.id) continue
      const cur = cache.get(u.id)
      if (cur) cache.set(u.id, { ...cur, ...u })
    }
    emit('groups.update', updates)
  })

  sock.ev.on('group-participants.update', event => {
    if (event?.id) applyParticipantsChange(cache, event.id, event.action, event.participants)
    emit('group-participants.update', event)
  })
}
