import config from '../config.js'

// ─────────────────────────────────────────────────────────────
//  ثوابت
// ─────────────────────────────────────────────────────────────

const name = config.botName

const RLM = '\u200f'
const TOP = `╭─❖ ${name} ❖─`
const BOTTOM = '╰─────────────❖'
const EMPTY_LINE = `${RLM}│`
const ROW_PREFIX = `${RLM}│ ◈ `

// ─────────────────────────────────────────────────────────────
//  box — صندوق عنوان + صفوف
// ─────────────────────────────────────────────────────────────

export function box(title, rows = []) {
  const out = [RLM + TOP]

  if (title) {
    out.push(`${RLM}│ ✦ *${title}*`)
    if (rows.length) out.push(EMPTY_LINE)
  }

  for (const r of rows) {
    out.push(r === '' ? EMPTY_LINE : ROW_PREFIX + r)
  }

  out.push(RLM + BOTTOM)
  return out.join('\n')
}

// ─────────────────────────────────────────────────────────────
//  single — رسالة بسيطة بإطار وأيقونة
// ─────────────────────────────────────────────────────────────

/**
 * إضافة RLM في بداية كل سطر من النص الداخلي
 * لتثبيت اتجاه النص العربي داخل الصندوق.
 */
const prefixLines = text =>
  String(text).split('\n').join(`\n${RLM}`)

const single = icon => text =>
  `${RLM}${TOP}\n${RLM}│ ${icon} ${prefixLines(text)}\n${RLM}${BOTTOM}`

// ─────────────────────────────────────────────────────────────
//  التصدير
// ─────────────────────────────────────────────────────────────

export const ui = {
  name,
  box,
  ok: single('✅'),
  err: single('❌'),
  warn: single('⚠️'),
  info: single('✦'),
  deny: single('⛔'),
}

export default ui