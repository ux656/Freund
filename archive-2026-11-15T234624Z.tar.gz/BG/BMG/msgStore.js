// ─────────────────────────────────────────────────────────────
//  كاش رسائل البوت المرسلة (لمنع معالجة رسائل البوت كأوامر)
// ─────────────────────────────────────────────────────────────

const store = new Map()

// ─────────────────────────────────────────────────────────────
//  الثوابت
// ─────────────────────────────────────────────────────────────

const LIMIT = 5_000
const TTL_MS = 30 * 60_000          // 30 دقيقة
const CLEANUP_INTERVAL = 5 * 60_000 // كل 5 دقائق
const CLEANUP_THRESHOLD = Math.floor(LIMIT * 0.8)

// ─────────────────────────────────────────────────────────────
//  الحالة الداخلية
// ─────────────────────────────────────────────────────────────

let lastCleanup = Date.now()

// ─────────────────────────────────────────────────────────────
//  التنظيف
// ─────────────────────────────────────────────────────────────

/** إزالة العناصر القديمة (FIFO) */
function evictOldest(count = 1) {
  for (let i = 0; i < count; i++) {
    const key = store.keys().next().value
    if (key === undefined) break
    store.delete(key)
  }
}

/** إزالة العناصر المنتهية صلاحيتها */
function evictExpired(now = Date.now()) {
  const cutoff = now - TTL_MS
  for (const [id, entry] of store) {
    if (entry.t >= cutoff) break // Map يحتفظ بالترتيب الزمني
    store.delete(id)
  }
}

/** تنظيف دوري خفيف — يعمل فقط عند تجاوز عتبة الحجم أو مرور وقت كافٍ */
function maybeCleanup() {
  const now = Date.now()
  if (store.size >= CLEANUP_THRESHOLD || now - lastCleanup >= CLEANUP_INTERVAL) {
    evictExpired(now)
    lastCleanup = now
  }
}

// ─────────────────────────────────────────────────────────────
//  الواجهة العامة
// ─────────────────────────────────────────────────────────────

/**
 * light = true (البوتات الفرعية): نحفظ المعرّف فقط بدون محتوى الرسالة،
 * يكفي لتجاهل ردود البوت نفسه ولا ياكل ذاكرة.
 */
export function rememberSent(sent, { light = false } = {}) {
  const id = sent?.key?.id
  if (!id) return

  // إزالة العنصر القديم لو موجود (لمنع تكرار المفتاح)
  if (store.has(id)) store.delete(id)

  store.set(id, {
    message: light ? null : (sent.message || null),
    t: Date.now(),
  })

  // عند تجاوز الحد: نظّف المنتهي أولاً، وإلا احذف الأقدم
  if (store.size > LIMIT) {
    evictExpired()
    if (store.size > LIMIT) evictOldest(store.size - LIMIT)
  }

  maybeCleanup()
}

export function getStoredMessage(key) {
  const id = key?.id
  if (!id) return undefined
  return store.get(id)?.message
}

export function isSentByBot(id) {
  if (!id) return false
  const entry = store.get(id)
  if (!entry) return false

  // فحص TTL عند القراءة
  if (Date.now() - entry.t > TTL_MS) {
    store.delete(id)
    return false
  }
  return true
}

// ─────────────────────────────────────────────────────────────
//  أدوات إضافية (اختيارية)
// ─────────────────────────────────────────────────────────────

/** حجم الكاش الحالي */
export const storeSize = () => store.size

/** مسح كامل للكاش (مفيد في الاختبارات) */
export const clearStore = () => {
  store.clear()
  lastCleanup = Date.now()
}