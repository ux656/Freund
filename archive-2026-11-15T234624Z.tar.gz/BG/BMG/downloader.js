// BMG-BOT — نواة تحميل وبحث الوسائط
// بتشتغل بـ fetch المدمج (Node >= 20) من غير أي مكتبات خارجية
// مدعوم حالياً: يوتيوب (بحث + فيديو + صوت) — تيك توك (رابط فيديو/صور/صوت)

// ─────────────────────────────────────────────────────────────
//  الثوابت
// ─────────────────────────────────────────────────────────────

export const LIMITS = {
  maxBytes: 50 * 1024 * 1024,   // الملف كله يُحمَّل في الذاكرة: حد صغير يناسب الموارد المحدودة
  maxDurationSec: 60 * 60,
  searchResults: 10,
}

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
const UNITS = ['B', 'KB', 'MB', 'GB']

const DEFAULT_TIMEOUT = 30_000
const BUFFER_TIMEOUT = 180_000
const CHUNK_TIMEOUT = 120_000
const CHUNK_SIZE = 9 * 1024 * 1024
const IMAGE_MAX_BYTES = 20 * 1024 * 1024

// ─────────────────────────────────────────────────────────────
//  التنسيقات
// ─────────────────────────────────────────────────────────────

export const fmtBytes = n => {
  let x = Number(n) || 0
  let i = 0
  while (x >= 1024 && i < UNITS.length - 1) { x /= 1024; i++ }
  return i ? `${x.toFixed(x >= 10 ? 0 : 1)}${UNITS[i]}` : `${x}${UNITS[i]}`
}

export const fmtTime = sec => {
  const s = Math.max(0, Math.floor(Number(sec) || 0))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const p2 = n => String(n).padStart(2, '0')
  return h ? `${h}:${p2(m)}:${p2(s % 60)}` : `${m}:${p2(s % 60)}`
}

const durToSec = text => {
  const parts = String(text || '').split(':').map(Number).reverse()
  return (parts[0] || 0) + (parts[1] || 0) * 60 + (parts[2] || 0) * 3600
}

// ─────────────────────────────────────────────────────────────
//  طبقة الشبكة
// ─────────────────────────────────────────────────────────────

async function absFetch(url, init = {}, timeoutMs = DEFAULT_TIMEOUT) {
  let res
  try {
    res = await fetch(url, {
      ...init,
      signal: init.signal || AbortSignal.timeout(timeoutMs),
      headers: { 'user-agent': UA, ...(init.headers || {}) },
    })
  } catch (e) {
    throw new Error(
      e?.name === 'TimeoutError'
        ? 'الطلب أخد وقت طويل، حاول تاني'
        : 'تعذر الاتصال بالخادم، حاول تاني',
    )
  }
  if (!res.ok) throw new Error(`الطلب فشل (HTTP ${res.status})`)
  return res
}

export async function fetchJson(url, init = {}) {
  const res = await absFetch(url, init)
  try {
    return await res.json()
  } catch {
    throw new Error('الخادم بيرد رد مش سليم (مش JSON)')
  }
}

async function readLimited(res, maxBytes) {
  const total = Number(res.headers.get('content-length') || 0)
  if (total > maxBytes) {
    try { await res.body?.cancel() } catch { /* ignored */ }
    throw new Error(`الملف كبير (${fmtBytes(total)}) والحد الأقصى ${fmtBytes(maxBytes)}`)
  }

  const reader = res.body?.getReader?.()
  if (!reader) throw new Error('الخادم مبعتش البيانات')

  const chunks = []
  let got = 0
  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    got += value.length
    if (got > maxBytes) {
      try { await reader.cancel() } catch { /* ignored */ }
      throw new Error(`الملف أكبر من الحد المسموح (${fmtBytes(maxBytes)})`)
    }
    chunks.push(value)
  }
  return Buffer.concat(chunks)
}

/** هل الخطأ خطأ "حجم" يجب ألا يُعاد المحاولة بعده؟ */
const isSizeError = msg => /كبير|أكبر/.test(String(msg || ''))

/**
 * يرجّع Buffer للملف مع حد أقصى للحجم.
 * روابط googlevideo تُحمَّل على أجزاء لتجنّب انقطاع الاتصال.
 */
// أقصى عدد تحميلات متزامنة (كل تحميل يسكن الذاكرة كاملاً) + طابور انتظار قصير
const MAX_CONCURRENT_DOWNLOADS = 2
const MAX_DOWNLOAD_QUEUE = 4
let activeDownloads = 0
const downloadQueue = []

async function acquireDownloadSlot() {
  if (activeDownloads < MAX_CONCURRENT_DOWNLOADS) {
    activeDownloads++
    return
  }
  if (downloadQueue.length >= MAX_DOWNLOAD_QUEUE) {
    throw new Error('البوت مشغول بتحميلات أخرى، حاول بعد دقيقة')
  }
  await new Promise(resolve => downloadQueue.push(resolve))
}

function releaseDownloadSlot() {
  const next = downloadQueue.shift()
  if (next) next()          // الخانة تنتقل للتالي مباشرة
  else activeDownloads--
}

export async function fetchBuffer(url, maxBytes = LIMITS.maxBytes, knownSize = 0) {
  await acquireDownloadSlot()
  try {
    return await fetchBufferUnlimited(url, maxBytes, knownSize)
  } finally {
    releaseDownloadSlot()
  }
}

async function fetchBufferUnlimited(url, maxBytes, knownSize) {
  const isGoogleVideo = /googlevideo\.com/i.test(url)

  if (isGoogleVideo && knownSize > 0) {
    if (knownSize > maxBytes) {
      throw new Error(`الملف كبير (${fmtBytes(knownSize)}) والحد الأقصى ${fmtBytes(maxBytes)}`)
    }
    try {
      const parts = []
      for (let start = 0; start < knownSize; start += CHUNK_SIZE) {
        const end = Math.min(start + CHUNK_SIZE, knownSize) - 1
        const u = `${url}${url.includes('?') ? '&' : '?'}range=${start}-${end}`
        const res = await absFetch(u, {}, CHUNK_TIMEOUT)
        parts.push(await readLimited(res, maxBytes))
      }
      const buffer = Buffer.concat(parts)
      return { buffer, size: buffer.length }
    } catch (e) {
      if (isSizeError(e.message)) throw e
      // فشل التحميل المُجزّأ — نكمل لتحميل عادي
    }
  }

  const res = await absFetch(url, {}, BUFFER_TIMEOUT)
  const buffer = await readLimited(res, maxBytes)
  return {
    buffer,
    size: buffer.length,
    mime: res.headers.get('content-type') || '',
  }
}

// ─────────────────────────────────────────────────────────────
//  كشف الروابط والمنصات
// ─────────────────────────────────────────────────────────────

export const detectUrl = text =>
  (String(text || '').match(/https?:\/\/[^\s]+/i) || [])[0] || ''

export function detectPlatform(url) {
  const u = String(url || '').toLowerCase()
  if (/(youtu\.be|youtube\.com|youtube-nocookie\.com)/.test(u)) return 'youtube'
  if (/tiktok\.com/.test(u)) return 'tiktok'
  return ''
}

const YT_URL_PATTERNS = [
  /youtu\.be\/([\w-]{11})/i,
  /[?&]v=([\w-]{11})/i,
  /\/shorts\/([\w-]{11})/i,
  /\/embed\/([\w-]{11})/i,
  /\/live\/([\w-]{11})/i,
]

export function parseVideoId(text) {
  const s = String(text || '')
  for (const re of YT_URL_PATTERNS) {
    const m = s.match(re)
    if (m) return m[1]
  }
  // كلمة 11 حرف تُعتبر ID فقط لو فيها رقم أو - أو _ أو حروف كبيرة+صغيرة
  const t = s.trim()
  if (/^[\w-]{11}$/.test(t) && (/[\d_-]/.test(t) || (/[a-z]/.test(t) && /[A-Z]/.test(t)))) {
    return t
  }
  return ''
}

// ─────────────────────────────────────────────────────────────
//  يوتيوب
// ─────────────────────────────────────────────────────────────

/** استخراج ytInitialData بمطابقة الأقواس (أدق من regex) */
export function extractInitialData(html) {
  const at = String(html).search(/ytInitialData\s*=\s*\{/)
  if (at < 0) return null
  const start = html.indexOf('{', at)

  let depth = 0
  let inStr = false
  let esc = false

  for (let i = start; i < html.length; i++) {
    const ch = html[i]
    if (inStr) {
      if (esc) esc = false
      else if (ch === '\\') esc = true
      else if (ch === '"') inStr = false
      continue
    }
    if (ch === '"') inStr = true
    else if (ch === '{') depth++
    else if (ch === '}' && --depth === 0) {
      try { return JSON.parse(html.slice(start, i + 1)) } catch { return null }
    }
  }
  return null
}

export async function ytSearch(query, limit = LIMITS.searchResults) {
  const html = await absFetch(
    `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&hl=ar&gl=EG`,
    { headers: { 'accept-language': 'ar,en;q=0.8' } },
  ).then(r => r.text())

  const data = extractInitialData(html)
  if (!data) throw new Error('تعذر قراءة نتايج يوتيوب، حاول تاني')

  const results = []
  const seen = new Set()

  const walk = node => {
    if (!node || results.length >= limit) return
    if (Array.isArray(node)) { for (const x of node) walk(x); return }
    if (typeof node !== 'object') return

    const vr = node.videoRenderer
    if (vr?.videoId && !seen.has(vr.videoId)) {
      seen.add(vr.videoId)
      results.push({
        id: vr.videoId,
        title: vr.title?.runs?.[0]?.text || vr.title?.simpleText || '',
        author: vr.ownerText?.runs?.[0]?.text || '',
        time: vr.lengthText?.simpleText || '',
        views: vr.viewCountText?.simpleText || '',
        durationSec: durToSec(vr.lengthText?.simpleText),
        thumbnail: `https://i.ytimg.com/vi/${vr.videoId}/hqdefault.jpg`,
      })
    }
    for (const v of Object.values(node)) walk(v)
  }

  walk(data)
  if (!results.length) throw new Error(`مفيش نتايج لـ «${query}»`)
  return results
}

// ─────────────────────────────────────────────────────────────
//  يوتيوب — مشغّل الفيديو
// ─────────────────────────────────────────────────────────────

const PLAY_STATUS_REASON = {
  LOGIN_REQUIRED: 'الفيديو ده محتاج تسجيل دخول',
  AGE_RESTRICTED: 'الفيديو مش متاح (تقييد سن)',
  UNPLAYABLE: 'الفيديو مش متاح للعرض',
  VIDEO_UNAVAILABLE: 'الفيديو مش موجود',
  ERROR: 'يوتيوب رفض الفيديو',
}

const CLIENTS = [
  { clientName: 'ANDROID_VR', clientVersion: '1.62.27', deviceMake: 'Meta', deviceModel: 'Quest 3', osName: 'Android', osVersion: '34' },
  { clientName: 'IOS', clientVersion: '20.10.4', deviceModel: 'iPhone16,2', osName: 'iPhone', osVersion: '18.3.2.22D68' },
  { clientName: 'WEB', clientVersion: '2.20250312.10.00' },
]

function collectFormats(streamingData = {}) {
  const out = []
  for (const key of ['formats', 'adaptiveFormats']) {
    for (const f of streamingData[key] || []) {
      // نريد روابط مباشرة فقط (بدون توقيع)
      if (!f?.url || f.s || f.signatureCipher) continue
      const mime = String(f.mimeType || '').split(';')[0]
      if (!mime) continue
      out.push({
        url: f.url,
        mime,
        combined: key === 'formats',
        height: f.height || 0,
        quality: f.qualityLabel || '',
        bitrate: f.bitrate || f.averageBitrate || 0,
        size: Number(f.contentLength || f.filesize || 0),
      })
    }
  }
  return out
}

async function ytPlayer(videoId) {
  let lastErr = null
  for (const client of CLIENTS) {
    try {
      const j = await fetchJson('https://www.youtube.com/youtubei/v1/player', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ videoId, context: { client: { hl: 'ar', gl: 'EG', ...client } } }),
      })
      const status = j?.playabilityStatus?.status
      if (status && status !== 'OK') {
        throw new Error(PLAY_STATUS_REASON[status] || `يوتيوب رفض التشغيل (${status})`)
      }
      const details = j?.videoDetails
      const formats = collectFormats(j?.streamingData)
      if (!details || !formats.length) {
        throw new Error(`العميل ${client.clientName} رجع مفيش روابط مباشرة`)
      }
      return { details, formats }
    } catch (e) {
      lastErr = e
    }
  }
  throw lastErr || new Error('تعذر جلب روابط الفيديو')
}

// ─────────────────────────────────────────────────────────────
//  يوتيوب — معلومات + اختيار المصدر
// ─────────────────────────────────────────────────────────────

const isMp4Audio = f => f.mime === 'audio/mp4'

export async function ytInfo(input) {
  let videoId = input && typeof input === 'object'
    ? String(input.id || '')
    : parseVideoId(input)

  if (!videoId) {
    const hits = await ytSearch(String(input || '').trim(), 1)
    videoId = hits[0]?.id || ''
    if (!videoId) throw new Error('مفيش نتايج — جرّب كلمات تانية')
  }

  const { details, formats } = await ytPlayer(videoId)
  const durationSec = Math.floor(+details.lengthSeconds || 0)

  if (details.isLiveContent) throw new Error('مينفعش تحميل البث المباشر')
  if (durationSec > LIMITS.maxDurationSec) {
    throw new Error(`الفيديو طويل (${fmtTime(durationSec)}) والحد الأقصى ${fmtTime(LIMITS.maxDurationSec)}`)
  }

  const video = formats
    .filter(f => f.mime.startsWith('video/'))
    .sort((a, b) =>
      (Number(b.combined) - Number(a.combined)) ||
      (b.height - a.height) ||
      (b.size - a.size),
    )

  // واتساب يشغّل m4a فقط، فتفضيل audio/mp4 على webm
  const audio = formats
    .filter(f => f.mime.startsWith('audio/'))
    .sort((a, b) =>
      (Number(isMp4Audio(b)) - Number(isMp4Audio(a))) ||
      (b.bitrate - a.bitrate) ||
      (b.size - a.size),
    )

  if (!video.length && !audio.length) {
    throw new Error('مفيش روابط تحميل متاحة للفيديو ده')
  }

  return {
    platform: 'youtube',
    videoId,
    title: details.title || '',
    author: details.author || '',
    views: +details.viewCount || 0,
    durationSec,
    thumbnail: details.thumbnails?.at(-1)?.url || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    sources: { video, audio },
  }
}

export function pickVideoSource(info, maxHeight = 0) {
  const list = info?.sources?.video || []
  const inLimit = f => f.combined && (!maxHeight || (f.height && f.height <= maxHeight))
  return (
    list.find(inLimit) ||
    list.find(f => f.combined) ||
    null
  )
}

export function pickAudioSource(info) {
  return (info?.sources?.audio || [])[0] || null
}

// ─────────────────────────────────────────────────────────────
//  تيك توك
// ─────────────────────────────────────────────────────────────

const TIKTOK_API = 'https://tikwm.com/api/'

const absTikTokUrl = u =>
  u
    ? (u.startsWith('http') ? u : `https://tikwm.com/${String(u).replace(/^\/+/, '')}`)
    : ''

export async function tiktokInfo(url) {
  const api = `${TIKTOK_API}?hd=1&url=${encodeURIComponent(url)}`
  let j = await fetchJson(api)

  // الخدمة تحدّد طلب/ثانية — نعيد مرة واحدة بعد انتظار قصير
  if (j?.code !== 0 && /limit|second/i.test(String(j?.msg || ''))) {
    await new Promise(r => setTimeout(r, 1500))
    j = await fetchJson(api)
  }

  if (!j || j.code !== 0 || !j.data) {
    throw new Error(typeof j?.msg === 'string' && j.msg ? j.msg : 'تعذر جلب الفيديو من تيك توك')
  }

  const d = j.data
  const video = absTikTokUrl(d.hdplay || d.play)
  const images = Array.isArray(d.images) ? d.images.map(absTikTokUrl) : []

  if (!video && !images.length) {
    throw new Error('مفيش محتوى قابل للتحميل في الرابط ده')
  }

  return {
    platform: 'tiktok',
    title: d.title || '',
    author: d.author?.nickname || d.author?.unique_id || '',
    durationSec: +d.duration || 0,
    thumbnail: absTikTokUrl(d.cover),
    video,
    images,
    audio: absTikTokUrl(d.music),
  }
}

// ─────────────────────────────────────────────────────────────
//  إرسال عبر Baileys
// ─────────────────────────────────────────────────────────────

const q = mek => (mek ? { quoted: mek } : {})
const caption_ = c => (c && String(c).trim()) || undefined

export async function sendVideo(sock, jid, url, caption = '', mek = null, size = 0) {
  const { buffer } = await fetchBuffer(url, LIMITS.maxBytes, size)
  return sock.sendMessage(jid, {
    video: buffer,
    mimetype: 'video/mp4',
    caption: caption_(caption),
  }, q(mek))
}

export async function sendAudio(
  sock, jid, url, caption = '', mek = null,
  { mimetype = 'audio/mpeg', size = 0, fileName = 'audio' } = {},
) {
  const { buffer } = await fetchBuffer(url, LIMITS.maxBytes, size)

  // واتساب لا يشغّل webm كصوت — نرسله كملف
  if (/webm|ogg/i.test(mimetype) && !/opus/i.test(mimetype)) {
    return sock.sendMessage(jid, {
      document: buffer,
      mimetype,
      fileName: `${fileName}.webm`,
    }, q(mek))
  }

  return sock.sendMessage(jid, {
    audio: buffer,
    ptt: false,
    mimetype,
  }, q(mek))
}

export async function sendImage(sock, jid, url, caption = '', mek = null) {
  const { buffer } = await fetchBuffer(url, IMAGE_MAX_BYTES)
  return sock.sendMessage(jid, {
    image: buffer,
    caption: caption_(caption),
  }, q(mek))
}