import fs from 'node:fs/promises'
import path from 'node:path'
import { log } from './logger.js'

// ─────────────────────────────────────────────────────────────
//  تنظيف مجلد جلسة (واتساب) من الملفات عديمة الفائدة
//  آمن: لا يلمس creds.json ولا ملفات session-* ولا pre-key-* ولا app-state-*
// ─────────────────────────────────────────────────────────────

export const CLEAN_INTERVAL_MS = 30 * 60_000   // كل نصف ساعة

const TMP_MAX_AGE = 10 * 60_000                // ملفات .tmp المتروكة
const CORRUPT_MIN_AGE = 5 * 60_000             // لا نحكم على ملف تالف إلا بعد ما يستقر (يمكن يكون يتكتب الحين)
const SENDER_KEY_MEMORY_MAX_AGE = 24 * 3600_000 // sender-key-memory يُعاد بناؤه تلقائياً

async function isValidJson(file) {
  try {
    JSON.parse(await fs.readFile(file, 'utf8'))
    return true
  } catch {
    return false
  }
}

/**
 * ينظف مجلد جلسة واحد، ويرجّع عدد الملفات المحذوفة.
 */
export async function cleanSessionDir(dir) {
  let entries
  try {
    entries = await fs.readdir(dir, { withFileTypes: true })
  } catch {
    return 0
  }

  const now = Date.now()
  let removed = 0

  for (const entry of entries) {
    if (!entry.isFile()) continue
    const name = entry.name
    if (name === 'creds.json' || name.startsWith('.')) continue

    const file = path.join(dir, name)
    try {
      const st = await fs.stat(file)
      const age = now - st.mtimeMs
      let remove = false

      if (name.endsWith('.tmp')) remove = age > TMP_MAX_AGE
      else if (st.size === 0) remove = age > CORRUPT_MIN_AGE
      else if (name.startsWith('sender-key-memory-')) remove = age > SENDER_KEY_MEMORY_MAX_AGE
      else if (name.endsWith('.json') && age > CORRUPT_MIN_AGE) remove = !(await isValidJson(file))

      if (remove) {
        await fs.unlink(file)
        removed++
      }
    } catch { /* الملف اختفى أو مقفول — نتجاهله */ }
  }

  return removed
}

/** تنظيف عدة مجلدات واحد بعد واحد (بدون ما نخنق الـ event loop). */
export async function cleanSessionDirs(dirs, label = 'sessions') {
  let total = 0
  for (const dir of dirs) {
    total += await cleanSessionDir(dir)
    await new Promise(resolve => setImmediate(resolve))
  }
  if (total) log.info(`${label}: cleaned ${total} useless file(s)`)
  return total
}
