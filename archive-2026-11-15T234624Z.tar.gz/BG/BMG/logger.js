// ─────────────────────────────────────────────────────────────
//  أدوات الألوان والتحكم في الطرفية
// ─────────────────────────────────────────────────────────────

const c = n => `\x1b[38;5;${n}m`
const R = '\x1b[0m'
const B = '\x1b[1m'
const D = '\x1b[2m'

// كشف دعم ANSI: بعض الطرفيات (Docker, CI) لا تدعم الألوان
const SUPPORTS_COLOR = (() => {
  if (process.env.NO_COLOR) return false
  if (process.env.FORCE_COLOR) return true
  return Boolean(process.stdout?.isTTY)
})()

// دالة ألوان آمنة: تعيد النص كما هو إذا لم يكن مدعوماً
const paint = (fn, value) => (SUPPORTS_COLOR ? fn(value) : value)

const clock = () => new Date().toLocaleTimeString('en-GB', {
  hour12: false,
  timeZone: 'Africa/Cairo',
})

const out = line => process.stdout.write(line + '\n')

function tag(label, color) {
  const text = `${D}${clock()}${R} ${c(color)}${B}${label.padEnd(9)}${R}`
  return SUPPORTS_COLOR ? text : `[${clock()}] ${label.padEnd(9)}`
}

// ─────────────────────────────────────────────────────────────
//  الكائن الرئيسي
// ─────────────────────────────────────────────────────────────

export const log = {
  banner(name = 'BMG-BOT') {
    const art = [
      ' ██████╗  ███╗   ███╗  ██████╗ ',
      ' ██╔══██╗ ████╗ ████║ ██╔════╝ ',
      ' ██████╔╝ ██╔████╔██║ ██║  ███╗',
      ' ██╔══██╗ ██║╚██╔╝██║ ██║   ██║',
      ' ██████╔╝ ██║ ╚═╝ ██║ ╚██████╔╝',
      ' ╚═════╝  ╚═╝     ╚═╝  ╚═════╝ ',
    ]
    const shades = [51, 45, 39, 33, 99, 135]

    out('')
    art.forEach((line, i) => out(`${c(shades[i])}${B}${line}${R}`))
    out(`${D} ──────────────────────────────${R}`)
    out(` ${c(250)}WhatsApp bot  ${D}•${R}  ${c(45)}${name}${R}`)
    out('')
  },

  info: msg => out(`${tag('INFO', 39)} ${c(252)}${msg}${R}`),
  ok: msg => out(`${tag('READY', 42)} ${c(120)}${msg}${R}`),
  warn: msg => out(`${tag('WARN', 214)} ${c(222)}${msg}${R}`),
  error: msg => out(`${tag('ERROR', 203)} ${c(210)}${msg}${R}`),

  plugins: (n, ms) =>
    out(`${tag('PLUGINS', 141)} ${c(252)}${n} commands loaded ${D}(${ms})${R}`),

  reloaded({ added = [], removed = [], updated = [], total = 0, ms = '?' }) {
    const nice = f => f.replace(/\.js$/, '')
    const parts = [
      ...added.map(f => `${c(120)}+${nice(f)}${R}`),
      ...removed.map(f => `${c(203)}-${nice(f)}${R}`),
      ...updated.map(f => `${c(222)}~${nice(f)}${R}`),
    ]
    out(`${tag('PLUGINS', 141)} ${c(252)}updated${R} ${parts.join(' ')} ${D}(${total} loaded, ${ms})${R}`)
  },

  command: ({ name, user, chat, ms }) =>
    out(
      `${tag('COMMAND', 220)} ${c(255)}Command invoked : ${c(220)}${B}${name}${R} ` +
      `${D}│${R} ${c(249)}${user}${R} ` +
      `${D}│${R} ${c(244)}${chat}${R} ` +
      `${D}│${R} ${c(114)}${ms}${R}`,
    ),

  pair(code) {
    out('')
    out(` ${c(45)}╭──────────────────────────────╮${R}`)
    out(` ${c(45)}│${R}  Pairing code  ${c(226)}${B}${code}${R}  ${c(45)}│${R}`)
    out(` ${c(45)}╰──────────────────────────────╯${R}`)
    out(`${D} WhatsApp > Linked devices > Link with phone number${R}`)
    out('')
  },
}

// ─────────────────────────────────────────────────────────────
//  كتم الضوضاء من Baileys / libsignal
// ─────────────────────────────────────────────────────────────

const NOISE_PATTERNS = [
  /closing session/i,
  /opening session/i,
  /removing old closed session/i,
  /session already (closed|open)/i,
  /migrating session/i,
  /failed to decrypt message/i,
  /bad mac/i,
  /no matching sessions/i,
  /decrypted message with closed session/i,
  /no session found/i,
  /session error/i,
  /prekey bundle/i,
]

function isNoiseArg(a) {
  if (a && typeof a === 'object' && a.constructor?.name === 'SessionEntry') return true
  if (typeof a === 'string') return NOISE_PATTERNS.some(re => re.test(a))
  if (a instanceof Error) return NOISE_PATTERNS.some(re => re.test(a.message))
  return false
}

const isNoise = args => args.some(isNoiseArg)

let silenced = false

export function silenceNoise() {
  if (silenced) return
  silenced = true

  for (const m of ['log', 'info', 'warn', 'error', 'debug']) {
    const orig = console[m].bind(console)
    console[m] = (...args) => {
      if (!isNoise(args)) orig(...args)
    }
  }
}

// ─────────────────────────────────────────────────────────────
//  تنسيق المدة الزمنية
// ─────────────────────────────────────────────────────────────

export const fmtMs = ms => {
  if (!Number.isFinite(ms) || ms < 0) return '?'
  if (ms < 1000) return `${Math.round(ms)}ms`
  return `${(ms / 1000).toFixed(2)}s`
}

// تصدير داخلي مفيد للأوامر
export { paint, SUPPORTS_COLOR }