export default {
  botName: 'BMG-BOT',
  version: '1.0.0',

  prefix: ['.'],
  noPrefixInPrivate: true,

  sessionDir: 'season',

  // المالك الثابت: لا يمكن تغييره أو حذفه من أوامر واتساب.
  // يمكن تحديث هذه القائمة يدوياً من هذا الملف فقط.
  owners: [
    '201104625895@s.whatsapp.net',
    '151780386173139@lid',
  ],
  owner: '201104625895@s.whatsapp.net',

  // توافق مع الإصدارات السابقة؛ الرتب الجديدة تحفظ في data/ranks.json.
  developers: [],

  subbots: {
    enabled: true,
    maxConnections: 10,   // موارد محدودة: كل بوت فرعي ياكل ذاكرة. ارفعه تدريجياً وراقب سطر memory في اللوج
    sessionDir: 'subbots',
    pairingDelay: 5000,
    keepAliveIntervalMs: 30000,
  },

  server: {
    enabled: true,
    port: 24707,
    host: '0.0.0.0',
  },

  connection: {
    autoReconnect: true,
    reconnectDelay: 3000,
    maxReconnectDelay: 60000,
    maxReconnectAttempts: 0,
    connectionTimeout: 60000,
  },

  commands: {
    timeout: 30000,
    cooldown: 350,
    notifyOnDeny: true,
    showErrorsToDevsOnly: true,
  },

  logging: {
    level: 'info',
    logCommands: true,
    saveToFile: false,
    filePath: 'logs/bot.log',
  },
}