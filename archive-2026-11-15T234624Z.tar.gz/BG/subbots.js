import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import pino from 'pino'
import NodeCache from 'node-cache'
import {
  makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  Browsers,
  jidNormalizedUser,
} from '@whiskeysockets/baileys'
import config from './config.js'
import { handleMessage } from './handler.js'
import { rememberSent, getStoredMessage } from './BMG/msgStore.js'
import { log } from './BMG/logger.js'
import { parsePhone } from './BMG/phone.js'
import { cleanSessionDirs, CLEAN_INTERVAL_MS } from './BMG/sessionCleaner.js'
import { pruneCaches, dispatchGroupEvent } from './handler.js'
import { createGroupCache, attachGroupEvents } from './BMG/groupEvents.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT_DIR = path.resolve(__dirname, '..')
const SESSION_ROOT = path.resolve(ROOT_DIR, config.subbots?.sessionDir || 'subbots')
const runtimes = new Map()
let versionPromise
let maintenanceTimer = null

// ─────────────────────────────────────────────────────────────
//  قواعد الجلسات
// ─────────────────────────────────────────────────────────────
const UNLINKED_TTL = 60_000                 // جلسة طلبت كود ولم تتربط: تنحذف بعد دقيقة
const IDLE_TTL = 24 * 3600_000              // بوت فرعي ما أخذ أي أمر 24 ساعة: يتحذف
const TOUCH_THROTTLE = 60_000               // لا نكتب ملف النشاط أكثر من مرة بالدقيقة
const HEAL_COOLDOWN = 5 * 60_000
const LAST_USED_FILE = '.last_used'         // يبدأ بنقطة، المنظّف لا يلمسه
const fmtIdle = ms => (ms >= 3600_000 ? `${Math.round(ms / 3600_000)}h` : `${Math.round(ms / 60_000)}m`)
const ALIVE_FILE = path.join(SESSION_ROOT, '.alive')

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

function normalizeNumber(value) {
  return String(value || '').replace(/\D/g, '')
}

function isValidNumber(number) {
  return /^\d{7,15}$/.test(number)
}

/**
 * الحساب مربوط فعلياً؟
 * ملاحظة مهمة: Baileys يضبط creds.me بمجرد طلب كود الربط (قبل ما يدخل المستخدم الكود)،
 * فوجود me لا يعني الربط. الربط الحقيقي يترك registered أو account أو signalIdentities.
 */
const isLinked = creds => Boolean(
  creds?.registered || creds?.account || creds?.signalIdentities?.length,
)

function diskLinked(number) {
  try {
    const creds = JSON.parse(fs.readFileSync(path.join(SESSION_ROOT, number, 'creds.json'), 'utf8'))
    return isLinked(creds)
  } catch {
    return false
  }
}

// ── آخر استخدام (آخر أمر) ──
function readLastUsed(number) {
  try {
    const n = Number(fs.readFileSync(path.join(SESSION_ROOT, number, LAST_USED_FILE), 'utf8'))
    return Number.isFinite(n) && n > 0 ? n : 0
  } catch {
    return 0
  }
}

function writeLastUsed(number, t = Date.now()) {
  try {
    const dir = path.join(SESSION_ROOT, number)
    if (!fs.existsSync(dir)) return
    fs.writeFileSync(path.join(dir, LAST_USED_FILE), String(t))
  } catch { /* ignored */ }
}

function touch(number, runtime) {
  const now = Date.now()
  if (runtime && now - (runtime.lastTouch || 0) < TOUCH_THROTTLE) return
  if (runtime) runtime.lastTouch = now
  writeLastUsed(number, now)
}

/** إذا السيرفر كان مطفي، ما نحسبها على البوتات كأنها خاملة: نزحّف وقت آخر استخدام بقدر مدة الإطفاء */
function compensateDowntime() {
  let alive = 0
  try { alive = Number(fs.readFileSync(ALIVE_FILE, 'utf8')) || 0 } catch { /* first run */ }
  const downtime = alive ? Date.now() - alive : 0
  if (downtime < 5 * 60_000) return
  let shifted = 0
  for (const number of listSessionNumbers()) {
    const last = readLastUsed(number)
    if (!last) continue
    writeLastUsed(number, Math.min(Date.now(), last + downtime))
    shifted++
  }
  if (shifted) log.info(`subbots: server was down ${Math.round(downtime / 60_000)}m, idle clocks shifted for ${shifted} session(s)`)
}

function markAlive() {
  try {
    fs.mkdirSync(SESSION_ROOT, { recursive: true })
    fs.writeFileSync(ALIVE_FILE, String(Date.now()))
  } catch { /* ignored */ }
}

/** حد ذاكرة الحاوية (cgroup) لو معروف، وإلا 0 */
function containerMemLimit() {
  for (const file of ['/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory/memory.limit_in_bytes']) {
    try {
      const n = Number(fs.readFileSync(file, 'utf8').trim())
      if (Number.isFinite(n) && n > 0 && n < 64 * 1024 ** 3) return n
    } catch { /* ignored */ }
  }
  return 0
}

/** نرفض تنصيب بوت جديد لو الذاكرة قاربت تنتهي (كل بوت فرعي ياكل عشرات الميجابايت) */
function assertMemoryHeadroom() {
  const limit = containerMemLimit()
  if (!limit) return
  const rss = process.memoryUsage().rss
  if (rss + 60 * 1024 * 1024 > limit * 0.85) {
    throw new Error('ذاكرة البوت شبه ممتلئة، ما ينفع تنصيب بوت فرعي جديد الحين. جرّب لاحقاً أو احذف بوت ما تحتاجه')
  }
}

/** يتأكد إن الرقم مسجّل في واتساب. يرجّع true/false، أو null لو ما قدرنا نتحقق (ما نمنع التنصيب وقتها). */
async function existsOnWhatsApp(parentSock, number) {
  if (typeof parentSock?.onWhatsApp !== 'function') return null
  try {
    const result = await Promise.race([
      parentSock.onWhatsApp(`${number}@s.whatsapp.net`),
      sleep(8000).then(() => null),
    ])
    if (!Array.isArray(result)) return null
    if (result.length === 0) return false
    return result[0]?.exists !== false
  } catch {
    return null
  }
}

const deleteHint = number => {
  const lid = getSubBotLid(number)
  return lid ? `\`.حذف_بوت ${lid}\`` : 'أمر `.حذف_بوت` (بنفس الرقم اللي كتبته)'
}

/** رقم البوت الأساسي (من الاتصال الحالي، أو من ملف جلسته لو لسه ما اتصل) */
function getMainNumber() {
  if (global.mainBotNumber) return String(global.mainBotNumber)
  try {
    const file = path.resolve(ROOT_DIR, config.sessionDir || 'season', 'creds.json')
    const creds = JSON.parse(fs.readFileSync(file, 'utf8'))
    return normalizeNumber(String(creds?.me?.id || '').split(':')[0].split('@')[0])
  } catch {
    return ''
  }
}

// ── عرض الهوية: نعرض LID فقط، ما نعرض أرقام الهواتف (خصوصية) ──
const lidDigits = raw => String(raw || '').split('@')[0].split(':')[0].replace(/\D/g, '')

/** LID البوت الفرعي (من الاتصال الحالي، أو من creds.json لو مو متصل). فاضي لو غير معروف. */
export function getSubBotLid(number) {
  let raw = runtimes.get(number)?.sock?.user?.lid
  if (!raw && global.subbots instanceof Map) raw = global.subbots.get(number)?.user?.lid
  if (!raw) {
    try {
      const creds = JSON.parse(fs.readFileSync(path.join(SESSION_ROOT, number, 'creds.json'), 'utf8'))
      raw = creds?.me?.lid
    } catch { /* ignored */ }
  }
  const d = lidDigits(raw)
  return d ? `${d}@lid` : ''
}

/** يقبل رقم هاتف أو LID ويرجّع رقم الجلسة (اسم المجلد) أو null. */
export function resolveSubBotNumber(input) {
  const d = String(input || '').replace(/\D/g, '')
  if (!d) return null
  if (runtimes.has(d) || fs.existsSync(path.join(SESSION_ROOT, d))) return d
  const all = new Set([...listSessionNumbers(), ...runtimes.keys()])
  for (const number of all) {
    if (lidDigits(getSubBotLid(number)) === d) return number
  }
  return null
}

/** قائمة البوتات الفرعية المتصلة للعرض (بدون أرقام هواتف). */
export function getSubBotList() {
  const entries = global.subbots instanceof Map ? [...global.subbots.entries()] : []
  return entries.map(([number, sock]) => ({
    lid: getSubBotLid(number),
    name: sock?.user?.name || '',
    connectedAt: Number(sock?.subbotConnectedAt) || Date.now(),
  }))
}

function listSessionNumbers() {
  try {
    return fs.readdirSync(SESSION_ROOT, { withFileTypes: true })
      .filter(e => e.isDirectory() && isValidNumber(e.name))
      .map(e => e.name)
  } catch {
    return []
  }
}

function getVersion() {
  if (!versionPromise) {
    versionPromise = fetchLatestBaileysVersion()
      .catch(() => ({ version: undefined }))
  }
  return versionPromise
}

function removeFromGlobal(sock) {
  if (Array.isArray(global.conns)) {
    const index = global.conns.indexOf(sock)
    if (index >= 0) global.conns.splice(index, 1)
  }
  if (global.subbots instanceof Map) {
    for (const [key, value] of global.subbots) {
      if (value === sock) global.subbots.delete(key)
    }
  }
}

function addToGlobal(number, sock) {
  if (!Array.isArray(global.conns)) global.conns = []
  if (!(global.subbots instanceof Map)) global.subbots = new Map()
  const duplicate = global.conns.findIndex(item =>
    item !== sock && item?.user?.id &&
    String(item.user.id).split(':')[0] === String(sock.user?.id || '').split(':')[0],
  )
  if (duplicate >= 0) {
    try { global.conns[duplicate].end?.(undefined) } catch {}
    global.conns.splice(duplicate, 1)
  }
  if (!global.conns.includes(sock)) global.conns.push(sock)
  global.subbots.set(number, sock)
}

function sendPairing(parentSock, chat, quoted, text) {
  if (!parentSock || !chat) {
    log.info(text.replace(/\n/g, ' | '))
    return Promise.resolve()
  }
  return parentSock.sendMessage(chat, { text }, quoted ? { quoted } : {})
}


// ─────────────────────────────────────────────────────────────
//  حذف الجلسات (غير المرتبطة / الخاملة / الميتة)
// ─────────────────────────────────────────────────────────────

/** يوقف البوت الفرعي ويحذف مجلد جلسته. logout=true يفصل الجهاز من واتساب أولاً (best-effort). */
const destroying = new Map() // number -> Promise (يمنع الحذف المتكرر / المتزامن)

async function destroySession(number, opts = {}) {
  if (destroying.has(number)) return destroying.get(number)
  const job = (async () => {
    const runtime = runtimes.get(number)
    if (runtime) runtime.destroying = true
    if (opts.logout && runtime?.sock) {
      try {
        await Promise.race([runtime.sock.logout(), sleep(5000)])
      } catch { /* الجهاز يمكن مفصول أصلاً */ }
    }
    await stopSubBot(number)
    try {
      fs.rmSync(path.join(SESSION_ROOT, number), { recursive: true, force: true })
      log.info(`subbot ${number}: session deleted`)
    } catch (error) {
      log.error(`subbot ${number}: could not delete session: ${error.message}`)
    }
  })().finally(() => destroying.delete(number))
  destroying.set(number, job)
  return job
}

/** بعد طلب كود الربط: إن لم يتربط الرقم خلال دقيقة تنحذف الجلسة. */
function armUnlinkedTimer(number, runtime) {
  if (runtime.unlinkedTimer) return
  runtime.unlinkedTimer = setTimeout(() => {
    runtime.unlinkedTimer = null
    if (runtime.stopped) return
    if (isLinked(runtime.authState?.creds) || diskLinked(number)) return
    log.warn(`subbot ${number}: not linked within ${UNLINKED_TTL / 1000}s, deleting session`)
    destroySession(number).catch(error => log.error(`subbot ${number}: cleanup failed: ${error.message}`))
  }, UNLINKED_TTL)
  runtime.unlinkedTimer.unref?.()
}

/** إصلاح جلسة بوت فرعي (تكرار فشل فك التشفير): نحذف ملفات session-<user> من مجلده هو فقط ونعيد اتصاله. */
async function healSubBotSession(number, runtime, sock, user) {
  if (Date.now() - (runtime.lastHeal || 0) < HEAL_COOLDOWN) return
  runtime.lastHeal = Date.now()
  const dir = path.join(SESSION_ROOT, number)
  let removed = 0
  try {
    for (const f of fs.readdirSync(dir)) {
      if (f.startsWith(`session-${user}.`) || f.startsWith(`session-${user}_`)) {
        try { fs.unlinkSync(path.join(dir, f)); removed++ } catch { /* ignored */ }
      }
    }
  } catch { /* ignored */ }
  // بدون إعادة اتصال: مفاتيح الجلسة تُقرأ من الملفات، والجلسة تنبني من جديد عند الرسالة الجاية
  // (إعادة الاتصال كانت تقطع البوت كله بسبب مستخدم واحد وتطلّع Connection Closed)
  log.warn(`subbot ${number}: repaired ${removed} broken session file(s) for ${user}`)
}

// ─────────────────────────────────────────────────────────────
//  الصيانة الدورية (كل نصف ساعة)
// ─────────────────────────────────────────────────────────────
async function runMaintenance() {
  markAlive()
  const now = Date.now()
  const cleanDirs = []

  for (const number of listSessionNumbers()) {
    const runtime = runtimes.get(number)
    const dir = path.join(SESSION_ROOT, number)

    // 1) جلسة غير مرتبطة ومنسية (بقايا) — تنحذف
    if (!diskLinked(number)) {
      const pending = runtime?.unlinkedTimer
      let age = Infinity
      try { age = now - fs.statSync(dir).mtimeMs } catch { /* ignored */ }
      if (!pending && age > UNLINKED_TTL) {
        log.warn(`subbot ${number}: leftover unlinked session, deleting`)
        await destroySession(number)
      }
      continue
    }

    // 2) بوت فرعي ما أخذ أي أمر خلال 24 ساعة — تنحذف جلسته
    let last = readLastUsed(number)
    if (!last) { writeLastUsed(number, now); last = now }  // جلسة قديمة بدون سجل: نبدأ العد من الآن
    // جلسة ما تشتغلت أصلاً (مثلاً تجاوزت maxConnections) ما أخذت فرصة تستقبل أوامر: ما تنحذف بسبب الخمول
    if (runtime && now - last > IDLE_TTL) {
      log.warn(`subbot ${number}: no commands for ${fmtIdle(IDLE_TTL)}, deleting session`)
      await destroySession(number, { logout: true })
      continue
    }

    cleanDirs.push(dir)
  }

  await cleanSessionDirs(cleanDirs, 'subbots')
  pruneCaches()
}

function ensureMaintenance() {
  if (maintenanceTimer) return
  maintenanceTimer = setInterval(() => {
    runMaintenance().catch(error => log.error(`subbots maintenance: ${error.message}`))
  }, CLEAN_INTERVAL_MS)
  maintenanceTimer.unref?.()
}

function schedulePairing(number, runtime, sock, state, options = {}) {
  if (isLinked(state.creds) || runtime.pairingIssued || runtime.pairingPending) return
  runtime.pairingPending = true
  armUnlinkedTimer(number, runtime)
  clearTimeout(runtime.pairingTimer)
  runtime.pairingTimer = setTimeout(async () => {
    runtime.pairingPending = false
    if (runtime.sock !== sock || runtime.stopped || isLinked(state.creds)) return
    try {
      const raw = await sock.requestPairingCode(number)
      const code = raw?.match(/.{1,4}/g)?.join('-') || raw
      if (!code) throw new Error('Baileys returned an empty pairing code')
      runtime.pairingIssued = true
      options.onPairingCode?.(String(raw).replace(/-/g, ''), Date.now() + UNLINKED_TTL)

      const message =
        `🤖 *تنصيب بوت فرعي*\n\n` +
        `🔐 كود الربط: *${code}*\n\n` +
        `افتح واتساب في الرقم المطلوب، ثم الأجهزة المرتبطة، ثم ربط جهاز، واختر الربط برقم الهاتف وأدخل الكود.`

      await sendPairing(options.parentSock, options.notifyJid, options.quoted, message)
    } catch (error) {
      runtime.pairingIssued = false
      options.onPairingError?.(error)
      log.error(`subbot ${number}: pairing code request failed: ${error.message}`)
      await sendPairing(
        options.parentSock,
        options.notifyJid,
        options.quoted,
        `تعذر استخراج كود الربط: ${error.message}`,
      ).catch(() => {})
    }
  }, config.subbots?.pairingDelay ?? 5000)
  runtime.pairingTimer.unref?.()
}

async function connectSubBot(number, runtime, options = {}) {
  if (runtime.starting) return runtime.starting
  runtime.starting = (async () => {
    const sessionPath = path.join(SESSION_ROOT, number)
    fs.mkdirSync(sessionPath, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
    const { version } = await getVersion()
    const logger = pino({ level: 'silent' })
    // كاشات بانتهاء تلقائي (ما تتراكم مع الوقت) وتُعاد استخدامها بين إعادات الاتصال
    if (!runtime.caches) {
      runtime.caches = {
        retry: new NodeCache({ stdTTL: 300, checkperiod: 120, useClones: false }),
        devices: new NodeCache({ stdTTL: 300, checkperiod: 120, useClones: false }),
      }
    }
    if (!runtime.caches.groups) runtime.caches.groups = createGroupCache()
    const groupCache = runtime.caches.groups
    const msgRetryCache = runtime.caches.retry
    const userDevicesCache = runtime.caches.devices

    const sock = makeWASocket({
      version,
      logger,
      printQRInTerminal: false,
      browser: Browsers.windows('Chrome'),
      auth: state,
      msgRetryCache,
      msgRetryCounterCache: msgRetryCache,
      userDevicesCache,
      markOnlineOnConnect: true,
      generateHighQualityLinkPreview: true,
      syncFullHistory: false,
      cachedGroupMetadata: async jid => groupCache.get(jid),
      getMessage: async key => {
        try {
          const jid = jidNormalizedUser(key.remoteJid)
          return getStoredMessage({ ...key, remoteJid: jid })
        } catch {
          return undefined
        }
      },
      defaultQueryTimeoutMs: 60_000,
      connectTimeoutMs: 60_000,
      keepAliveIntervalMs: config.subbots?.keepAliveIntervalMs ?? 30_000,
      retryRequestDelayMs: 250,
      maxMsgRetryCount: 5,
    })

    runtime.sock = sock
    sock.isSubBot = true
    sock.subbotNumber = number
    runtime.number = number
    runtime.sessionPath = sessionPath
    runtime.authState = state
    runtime.stopped = false

    // البوت الفرعي: نحفظ المعرّف فقط (بدون محتوى الرسالة) — نعالج ونتجاهل
    const rawSendMessage = sock.sendMessage.bind(sock)
    sock.sendMessage = async (...args) => {
      const sent = await rawSendMessage(...args)
      rememberSent(sent, { light: true })
      return sent
    }

    // يستدعيها handler عند كل أمر معروف
    sock.touchActivity = () => touch(number, runtime)
    // يستدعيها handler عند تكرار فشل فك التشفير
    sock.healSession = user => healSubBotSession(number, runtime, sock, user)

    sock.ev.on('creds.update', async () => {
      // جلسة انحذفت/تنحذف: لا نكتب شيء (يمنع ENOENT)
      if (runtime.stopped || runtime.destroying || runtime.sock !== sock) return
      if (!fs.existsSync(sessionPath)) return
      try {
        await saveCreds()
        if (isLinked(state.creds)) {
          options.onStatus?.('linked')
          runtime.pairingIssued = true
          clearTimeout(runtime.unlinkedTimer)
          runtime.unlinkedTimer = null
        }
      } catch (error) {
        log.error(`subbot ${number}: could not save credentials: ${error.message}`)
      }
    })

    attachGroupEvents(sock, groupCache, {
      label: `subbot ${number}`,
      dispatch: (event, data) => {
        if (runtime.sock !== sock || runtime.stopped) return
        return dispatchGroupEvent(sock, event, data)
      },
    })

    sock.ev.on('messages.upsert', ({ messages, type }) => {
      if (runtime.sock !== sock || runtime.stopped) return
      if (!['notify', 'append', 'replace'].includes(type)) return
      for (const message of messages || []) {
        handleMessage(sock, message).catch(error => {
          // خطأ بسبب سوكيت انقفل/انحذف أثناء المعالجة: مو مشكلة
          if (sock.isDestroyed || runtime.stopped || runtime.destroying) return
          log.error(`subbot ${number}: message handler: ${error?.message || error}`)
        })
      }
    })

    sock.ev.on('connection.update', async update => {
      if (runtime.sock !== sock || runtime.stopped) return
      const { connection, lastDisconnect } = update

      if (connection === 'open') {
        runtime.attempts = 0
        runtime.openedAt = Date.now()
        sock.subbotConnectedAt = runtime.openedAt
        clearTimeout(runtime.unlinkedTimer)
        runtime.unlinkedTimer = null
        if (!readLastUsed(number)) writeLastUsed(number)
        addToGlobal(number, sock)
        options.onStatus?.('linked')
        log.ok(`subbot connected: ${number}`)
        return
      }

      if (connection !== 'close') return

      const code = lastDisconnect?.error?.output?.statusCode
      removeFromGlobal(sock)
      runtime.sock = null
      if (runtime.destroying || runtimes.get(number) !== runtime) return
      if (!isLinked(state.creds)) runtime.pairingIssued = false

      // المستخدم فصل الجهاز من واتساب: الجلسة ميتة، نحذفها
      if (code === DisconnectReason.loggedOut) {
        log.warn(`subbot ${number}: logged out from WhatsApp, deleting session`)
        destroySession(number, { logout: false }).catch(() => {})
        return
      }

      if ([401, 403, 405].includes(code)) {
        log.warn(`subbot ${number}: authentication/session rejected (${code}); session retained at ${sessionPath}`)
        return
      }

      // جلسة لم تتربط: ما نعيد الاتصال (كود الربط القديم ما يصلح بعد انقطاع الاتصال)
      // — مؤقّت الدقيقة هو اللي يحذفها. استثناء: restartRequired طبيعي بعد نجاح الربط.
      if (!isLinked(state.creds) && code !== DisconnectReason.restartRequired) {
        log.warn(`subbot ${number}: closed before linking (${code ?? 'unknown'}), waiting for cleanup`)
        return
      }

      const attempt = runtime.attempts++
      const base = config.connection?.reconnectDelay ?? 3000
      const max = config.connection?.maxReconnectDelay ?? 60_000
      const delay = code === DisconnectReason.restartRequired
        ? 500
        : code === DisconnectReason.connectionReplaced
          ? 30_000
          : Math.min(base * (2 ** Math.min(attempt, 5)), max)

      log.warn(`subbot ${number}: connection closed (${code ?? 'unknown'}), retry in ${delay}ms`)
      clearTimeout(runtime.timer)
      runtime.timer = setTimeout(() => {
        if (!runtime.stopped) {
          connectSubBot(number, runtime, { requestPairing: false })
            .catch(error => log.error(`subbot ${number}: reconnect failed: ${error.message}`))
        }
      }, delay)
      runtime.timer.unref?.()
    })

    if (options.requestPairing && !isLinked(state.creds)) {
      schedulePairing(number, runtime, sock, state, options)
    }

    return sock
  })()

  try {
    return await runtime.starting
  } finally {
    runtime.starting = null
  }
}

export async function startSubBot(input, options = {}) {
  if (config.subbots?.enabled === false) {
    throw new Error('نظام البوتات الفرعية معطل من config.js')
  }

  const number = normalizeNumber(input)
  if (!isValidNumber(number)) throw new Error('رقم الهاتف غير صالح')

  if (!fs.existsSync(SESSION_ROOT)) fs.mkdirSync(SESSION_ROOT, { recursive: true })
  if (!options.restore) {
    // صيغة الرقم (حتى لو انكتب من مكان غير أمر .تنصيب)
    const parsed = parsePhone([number])
    if (!parsed.ok) throw new Error(parsed.error)

    // ممنوع تنصيب رقم البوت الأساسي
    const mainNumber = getMainNumber()
    if (mainNumber && number === mainNumber) {
      throw new Error('هذا رقم البوت الأساسي، ما ينفع تنصبه كبوت فرعي')
    }

    // جلسة واحدة لكل رقم
    const existing = runtimes.get(number)
    const folder = path.join(SESSION_ROOT, number)
    if (existing?.sock || existing?.starting || existing?.unlinkedTimer) {
      throw new Error(
        existing.unlinkedTimer
          ? 'هذا الرقم عنده جلسة قيد الربط، انتظر دقيقة أو أكمل الربط بالكود اللي وصلك'
          : 'هذا الرقم له جلسة بالفعل. احذفها أولاً بـ ' + deleteHint(number),
      )
    }
    if (fs.existsSync(folder)) {
      if (diskLinked(number)) {
        throw new Error('هذا الرقم له جلسة بالفعل. احذفها أولاً بـ ' + deleteHint(number))
      }
      // بقايا جلسة غير مرتبطة قديمة: ننظفها ونكمل
      await destroySession(number)
    }

    assertMemoryHeadroom()

    // الرقم لازم يكون مسجّل في واتساب (يمسك الأرقام اللي صيغتها تبدو صحيحة وهي غير موجودة)
    if ((await existsOnWhatsApp(options.parentSock, number)) === false) {
      throw new Error('هذا الرقم غير مسجّل في واتساب، تأكد من كتابته')
    }
  }

  const runtime = runtimes.get(number) || { attempts: 0, timer: null, sock: null }
  runtimes.set(number, runtime)
  ensureMaintenance()

  if (runtime.sock) {
    if (options.requestPairing && runtime.authState && !runtime.authState.creds.registered) {
      schedulePairing(number, runtime, runtime.sock, runtime.authState, options)
    }
    return { number, connected: true, existing: true }
  }
  if (runtime.starting) {
    await runtime.starting
    return { number, connected: Boolean(runtime.sock), existing: true }
  }

  const count = [...runtimes.values()].filter(item => item.sock).length
  const max = Number(config.subbots?.maxConnections) || 100
  if (count >= max) throw new Error(`تم الوصول إلى حد الاتصالات الفرعية (${max})`)

  // تنصيب/تشغيل جديد = بداية عدّ الخمول
  if (options.requestPairing !== false) writeLastUsed(number)

  await connectSubBot(number, runtime, {
    ...options,
    requestPairing: options.requestPairing !== false,
  })
  return { number, connected: Boolean(runtime.sock), existing: false }
}

export async function startAllSubBots(parentSock = null) {
  if (!fs.existsSync(SESSION_ROOT)) return { started: 0, skipped: 0 }

  compensateDowntime()
  markAlive()
  ensureMaintenance()
  // أول صيانة بعد دقيقتين من الإقلاع
  setTimeout(() => runMaintenance().catch(e => log.error(`subbots maintenance: ${e.message}`)), 120_000).unref?.()

  const folders = fs.readdirSync(SESSION_ROOT, { withFileTypes: true })
    .filter(entry => entry.isDirectory() && isValidNumber(entry.name))
    .map(entry => entry.name)

  let started = 0
  let skipped = 0
  const max = Number(config.subbots?.maxConnections) || 100

  for (const number of folders) {
    if (started >= max) {
      skipped++
      continue
    }

    const creds = path.join(SESSION_ROOT, number, 'creds.json')
    if (!fs.existsSync(creds)) {
      skipped++
      continue
    }

    try {
      const parsed = JSON.parse(fs.readFileSync(creds, 'utf8'))
      if (!isLinked(parsed)) {
        skipped++
        continue
      }
      await startSubBot(number, { parentSock, requestPairing: false, restore: true })
      started++
      // تدرّج بدء الاتصالات لتجنب ضغط مفاجئ على الذاكرة والمعالج.
      await sleep(350)
    } catch (error) {
      log.error(`subbot ${number}: startup restore failed: ${error.message}`)
    }
  }

  log.info(`subbot recovery: ${started} started, ${skipped} skipped`)
  return { started, skipped }
}

export function getSubBotStats() {
  const active = [...runtimes.values()].filter(item => Boolean(item.sock)).length
  return {
    active,
    configured: fs.existsSync(SESSION_ROOT)
      ? fs.readdirSync(SESSION_ROOT, { withFileTypes: true }).filter(entry => entry.isDirectory()).length
      : 0,
    limit: Number(config.subbots?.maxConnections) || 100,
  }
}

/**
 * حذف بوت فرعي كاملاً: فصل الجهاز (إن أمكن) وحذف الجلسة.
 * يقبل رقم هاتف أو LID. يرجّع { lid } لو انحذف، أو null لو ما لقى الجلسة.
 */
export async function deleteSubBot(input) {
  const number = resolveSubBotNumber(input)
  if (!number) return null
  const lid = getSubBotLid(number)
  await destroySession(number, { logout: true })
  return { lid }
}

export async function stopSubBot(input) {
  const number = normalizeNumber(input)
  const runtime = runtimes.get(number)
  if (!runtime) return false
  runtime.stopped = true
  clearTimeout(runtime.timer)
  clearTimeout(runtime.pairingTimer)
  clearTimeout(runtime.unlinkedTimer)
  runtime.unlinkedTimer = null
  try { runtime.caches?.retry.close(); runtime.caches?.devices.close() } catch { /* ignored */ }
  if (runtime.sock) {
    runtime.sock.isDestroyed = true
    removeFromGlobal(runtime.sock)
    try { runtime.caches?.groups?.clear() } catch { /* ignored */ }
    try { runtime.sock.end(undefined) } catch {}
  }
  runtime.sock = null
  runtimes.delete(number)
  return true
}

export async function stopAllSubBots() {
  for (const number of [...runtimes.keys()]) {
    await stopSubBot(number)
  }
}
