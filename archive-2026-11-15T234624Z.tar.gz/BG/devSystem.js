import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import config from './config.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DATA_DIR = path.resolve(__dirname, '..', 'data')
const RANKS_FILE = path.join(DATA_DIR, 'ranks.json')

export const MAX_RANK = 100

export const RANKS = Object.freeze({
  1: 'owners',
  2: 'elite',
  3: 'developers',
})

export const RANK_NAMES = Object.freeze({
  owners: 'أونر',
  elite: 'نخبة',
  developers: 'مطور',
})

export const getNumber = jid => String(jid || '')
  .split('@')[0]
  .split(':')[0]
  .replace(/\D/g, '')

export const isLid = jid => String(jid || '').toLowerCase().endsWith('@lid')

export function normalizeJid(jid) {
  if (!jid) return ''
  const [user = '', server = ''] = String(jid).trim().split('@')
  const base = user.split(':')[0]
  return server ? `${base}@${server}` : base
}

const clean = list => [...new Set(
  (Array.isArray(list) ? list : [])
    .map(normalizeJid)
    .filter(x => x && getNumber(x)),
)]

function atomicWrite(file, content) {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`
  try {
    fs.writeFileSync(tmp, content, 'utf8')
    fs.renameSync(tmp, file)
  } catch (err) {
    try { fs.unlinkSync(tmp) } catch {}
    throw err
  }
}

let rankCache = { owners: [], elite: [], developers: [] }
let rankCacheMtime = -1
let rankCacheCheckedAt = 0

function cloneRanks(data) {
  return {
    owners: [...data.owners],
    elite: [...data.elite],
    developers: [...data.developers],
  }
}

function loadRanks() {
  const now = Date.now()
  if (now - rankCacheCheckedAt < 1000) return cloneRanks(rankCache)
  rankCacheCheckedAt = now
  let mtime = -1
  try { mtime = fs.statSync(RANKS_FILE).mtimeMs } catch {}
  if (mtime === rankCacheMtime) return cloneRanks(rankCache)

  try {
    const raw = JSON.parse(fs.readFileSync(RANKS_FILE, 'utf8'))
    rankCache = {
      owners: clean(raw.owners),
      elite: clean(raw.elite),
      developers: clean(raw.developers),
    }
  } catch {
    rankCache = { owners: [], elite: [], developers: [] }
  }
  rankCacheMtime = mtime
  return cloneRanks(rankCache)
}

function saveRanks(data) {
  const next = {
    owners: clean(data.owners),
    elite: clean(data.elite),
    developers: clean(data.developers),
  }
  atomicWrite(RANKS_FILE, JSON.stringify(next, null, 2))
  rankCache = next
  try { rankCacheMtime = fs.statSync(RANKS_FILE).mtimeMs } catch { rankCacheMtime = -1 }
  rankCacheCheckedAt = Date.now()
}

const fixedOwners = () => clean([
  ...(Array.isArray(config.owners) ? config.owners : []),
  config.owner,
])

const lidMappingCache = new Map()
const LID_CACHE_TTL = 5 * 60_000

async function getMappedPN(sock, lid) {
  const socketId = normalizeJid(sock?.user?.id || sock?.user?.lid || 'unknown')
  const key = `${socketId}|${lid}`
  const now = Date.now()
  const cached = lidMappingCache.get(key)
  if (cached && cached.expires > now) return cached.value

  let value = null
  try {
    value = await sock?.signalRepository?.lidMapping?.getPNForLID?.(lid) || null
  } catch {}

  if (lidMappingCache.size > 2000) {
    for (const [cacheKey, item] of lidMappingCache) {
      if (item.expires <= now) lidMappingCache.delete(cacheKey)
    }
  }
  lidMappingCache.set(key, { value, expires: now + (value ? LID_CACHE_TTL : 30_000) })
  return value
}

export async function sameIdentity(sock, a, b) {
  const x = normalizeJid(a)
  const y = normalizeJid(b)
  if (!x || !y) return false
  if (x.toLowerCase() === y.toLowerCase()) return true

  const xl = isLid(x)
  const yl = isLid(y)
  if (xl === yl) return !xl && getNumber(x) === getNumber(y)

  const lid = xl ? x : y
  const pn = xl ? y : x
  const mapped = await getMappedPN(sock, lid)
  return Boolean(mapped) && getNumber(mapped) === getNumber(pn)
}

async function inList(sock, jid, list) {
  for (const item of clean(list)) {
    if (await sameIdentity(sock, jid, item)) return item
  }
  return null
}

function botIds(sock) {
  // صلاحيات موحّدة: حساب البوت الفرعي نفسه مستخدم عادي، ما يأخذ صلاحية بسبب إنه رقم البوت.
  // الرتب (مالك/أونر/نخبة/مطور) تُحسب من config + ranks.json وتسري على كل البوتات.
  if (sock?.isSubBot) return []
  return [sock?.user?.id, sock?.user?.lid].filter(Boolean).map(normalizeJid)
}

export async function isOwner(sock, jid) {
  for (const owner of fixedOwners()) {
    if (await sameIdentity(sock, jid, owner)) return true
  }
  return false
}

export async function isBotAccount(sock, jid) {
  return Boolean(await inList(sock, jid, botIds(sock)))
}

// إجراء فحص صلاحيات واحد لكل رسالة بدلاً من تكرار فحص المالك والرتب عدة مرات.
export async function getAccess(sock, jids) {
  const candidates = [...new Set((Array.isArray(jids) ? jids : [jids])
    .filter(Boolean).map(normalizeJid))]
  const owners = fixedOwners()
  const bots = botIds(sock)
  const ranks = loadRanks()
  let owner = false
  let bot = false
  let rank = null

  for (const jid of candidates) {
    if (!owner) owner = await inList(sock, jid, owners)
    if (!bot) bot = await inList(sock, jid, bots)
    if (!rank && !owner) {
      for (const key of ['owners', 'elite', 'developers']) {
        if (await inList(sock, jid, ranks[key])) {
          rank = RANK_NAMES[key]
          break
        }
      }
    }
    if (owner) break
  }

  return {
    owner: Boolean(owner),
    dev: Boolean(owner || bot || rank),
    soldier: Boolean(owner || bot || rank),
    rank: owner ? 'مالك' : (rank || (bot ? 'حساب البوت' : null)),
  }
}

export async function getRank(sock, jid) {
  if (await isOwner(sock, jid)) return 'مالك'
  const data = loadRanks()
  for (const key of ['owners', 'elite', 'developers']) {
    if (await inList(sock, jid, data[key])) return RANK_NAMES[key]
  }
  return null
}

export async function isDev(sock, jid) {
  if (await isOwner(sock, jid) || await isBotAccount(sock, jid)) return true
  return Boolean(await getRank(sock, jid))
}

export async function isSoldier(sock, jid) {
  return isDev(sock, jid)
}

export function listRank(kind) {
  const data = loadRanks()
  if (kind === 'all') return data
  return { owner: fixedOwners(), stored: data[kind] || [] }
}

export async function addRank(sock, kind, jid) {
  if (!Object.hasOwn(RANK_NAMES, kind)) return { ok: false, reason: 'invalid_rank' }
  const target = normalizeJid(jid)
  if (!getNumber(target)) return { ok: false, reason: 'invalid' }
  if (await isOwner(sock, target) || await isBotAccount(sock, target)) {
    return { ok: false, reason: 'protected' }
  }

  const data = loadRanks()
  for (const key of Object.keys(RANK_NAMES)) {
    const existing = await inList(sock, target, data[key])
    if (existing) data[key] = data[key].filter(x => x !== existing)
  }

  if (data[kind].length >= MAX_RANK && !(await inList(sock, target, data[kind]))) {
    return { ok: false, reason: 'full' }
  }

  data[kind].push(target)
  saveRanks(data)
  return { ok: true, jid: target, rank: RANK_NAMES[kind] }
}

export async function removeRank(sock, kind, jid) {
  if (!Object.hasOwn(RANK_NAMES, kind)) return { ok: false, reason: 'invalid_rank' }
  const target = normalizeJid(jid)
  if (!getNumber(target)) return { ok: false, reason: 'invalid' }
  if (await isOwner(sock, target) || await isBotAccount(sock, target)) {
    return { ok: false, reason: 'protected' }
  }

  const data = loadRanks()
  const found = await inList(sock, target, data[kind])
  if (!found) return { ok: false, reason: 'not_found' }
  data[kind] = data[kind].filter(x => x !== found)
  saveRanks(data)
  return { ok: true, jid: found }
}

// ترحيل المطورين القدامى من config.js إلى ملف الرتب الجديد.
try {
  const legacy = clean(config.developers)
  if (legacy.length) {
    const data = loadRanks()
    data.developers = clean([...data.developers, ...legacy])
    saveRanks(data)
  }
} catch {}
