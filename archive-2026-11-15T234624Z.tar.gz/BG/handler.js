import fs from 'fs'
import path from 'path'
import { fileURLToPath, pathToFileURL } from 'url'
import config from './config.js'
import {
  getAccess, addRank, removeRank, listRank, getNumber, normalizeJid,
} from './devSystem.js'
import { log, fmtMs } from './BMG/logger.js'
import ui from './BMG/ui.js'
import { isSentByBot } from './BMG/msgStore.js'

// ─────────────────────────────────────────────────────────────
//  الثوابت والإعدادات الأولية
// ─────────────────────────────────────────────────────────────
const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PLUGIN_DIR = path.resolve(__dirname, '..', 'plugin')
const DATA_DIR = path.resolve(__dirname, '..', 'data')
const MODE_FILE = path.join(DATA_DIR, 'mode.json')
const STARTED_AT = Math.floor(Date.now() / 1000)

const SEEN_PER_BOT = 30   // آخر 30 رسالة لكل بوت (الأقدم يُحذف)
const COOLDOWN_MS = Number(config.commands?.cooldown) || 350
const COOLDOWN_WINDOW = 60_000
const MAX_WRAPPER_DEPTH = 5
const FOLDER_POLL_MS = 2000
const RELOAD_DEBOUNCE_MS = 80

const INVISIBLE_RE = /[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g
const INVISIBLE_START_RE = /^[\s\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]+/
const ARABIC_DIACRITICS_RE = /[\u064B-\u065F\u0670\u0640]/g

const WRAPPERS = [
  'ephemeralMessage',
  'viewOnceMessage',
  'viewOnceMessageV2',
  'viewOnceMessageV2Extension',
  'documentWithCaptionMessage',
  'deviceSentMessage',
  'editedMessage',
]

// ─────────────────────────────────────────────────────────────
//  تحميل NIXCODE (اختياري)
// ─────────────────────────────────────────────────────────────
const nix = await import('./BMG/NIXCODE.js').catch(err => {
  log.warn(`NIXCODE unavailable, continuing without it: ${err.message}`)
  return {}
})
const { Toolkit, Button, ButtonV2, Carousel, AIRich } = nix

// ─────────────────────────────────────────────────────────────
//  أدوات مساعدة (Utilities)
// ─────────────────────────────────────────────────────────────

/** تنميط الأمر: إزالة الرموز الخفية، توحيد الأحرف العربية، lowercase */
function normalizeCommand(str) {
  return String(str ?? '')
    .replace(INVISIBLE_RE, '')
    .normalize('NFKC')
    .replace(ARABIC_DIACRITICS_RE, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .trim()
    .toLowerCase()
}

/**
 * منع معالجة نفس الرسالة مرتين.
 * لكل بوت Map صغير يحفظ آخر SEEN_PER_BOT (30) رسالة فقط، والأقدم يُحذف.
 * المفتاح = المحادثة + معرّف الرسالة (بدون المرسل لأنه ممكن يتغير بين LID ورقم لنفس الرسالة).
 */
const seenByBot = new Map() // botScope -> Map(key -> true)
function seenBefore(botScope, key) {
  if (!key) return false
  let seen = seenByBot.get(botScope)
  if (!seen) {
    seen = new Map()
    seenByBot.set(botScope, seen)
  }
  if (seen.has(key)) return true
  seen.set(key, true)
  if (seen.size > SEEN_PER_BOT) seen.delete(seen.keys().next().value)
  return false
}

/** تنظيف الكاشات الصغيرة (تُستدعى دورياً) — لا نحتفظ بأي رسالة، فقط معرّفات مؤقتة */
export function pruneCaches() {
  const now = Date.now()
  for (const [k, t] of cooldowns) {
    if (now - t > COOLDOWN_WINDOW) cooldowns.delete(k)
  }
  for (const [k, v] of failures) {
    if (!v.some(t => now - t < 60_000)) failures.delete(k)
  }
}

/** كشف الرسائل المُلفوفة (ephemeral، viewOnce، إلخ) وإرجاع المحتوى الداخلي */
function unwrapMessage(message) {
  let cur = message
  for (let i = 0; cur && i < MAX_WRAPPER_DEPTH; i++) {
    const w = WRAPPERS.find(k => cur[k]?.message)
    if (!w) break
    cur = cur[w].message
  }
  return cur
}

function extractText(msg) {
  if (!msg) return ''
  return String(
    msg.conversation ||
    msg.extendedTextMessage?.text ||
    msg.imageMessage?.caption ||
    msg.videoMessage?.caption ||
    msg.documentMessage?.caption ||
    '',
  )
}

function extractSelectionId(msg) {
  if (!msg) return ''
  const pj = msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson
  if (pj) {
    try {
      const d = JSON.parse(pj)
      const nf = d?.id || d?.selected_id || d?.selectedId || d?.selectedRowId ||
                 d?.rowId || d?.button_id || d?.buttonId || ''
      if (nf) return String(nf)
    } catch { /* ignored */ }
  }
  return String(
    msg.listResponseMessage?.singleSelectReply?.selectedRowId ||
    msg.buttonsResponseMessage?.selectedButtonId ||
    msg.templateButtonReplyMessage?.selectedId ||
    '',
  )
}

function getContextInfo(msg) {
  if (!msg) return null
  for (const v of Object.values(msg)) {
    if (v && typeof v === 'object' && v.contextInfo) return v.contextInfo
  }
  return null
}

function getSenderJids(sock, mek, isGroup) {
  const k = mek.key
  const list = []
  if (k.fromMe) {
    list.push(sock.user?.id, sock.user?.lid)
  } else {
    list.push(k.participant, k.participantAlt, k.participantPn, mek.participant)
    if (!isGroup) list.push(k.remoteJid, k.remoteJidAlt)
  }
  return [...new Set(list.filter(Boolean).map(normalizeJid))]
}


// ─────────────────────────────────────────────────────────────
//  البادئات (Prefixes)
// ─────────────────────────────────────────────────────────────
let cachedPrefixes = ['.']

function refreshPrefixes() {
  const raw = config.prefix
  const list = (Array.isArray(raw) ? raw : [raw])
    .filter(p => typeof p === 'string' && p.length > 0)
  cachedPrefixes = (list.length ? list : ['.'])
    .sort((a, b) => b.length - a.length)
}

refreshPrefixes()
const getPrefixes = () => cachedPrefixes

const matchPrefix = body => cachedPrefixes.find(p => body.startsWith(p)) ?? null

// ─────────────────────────────────────────────────────────────
//  حالة الوضع (خاص / عام)
// ─────────────────────────────────────────────────────────────
let botMode = { selfOnly: false }
try {
  const raw = fs.readFileSync(MODE_FILE, 'utf8')
  botMode = { selfOnly: false, ...JSON.parse(raw) }
} catch { /* default */ }

function saveMode() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true })
    fs.writeFileSync(MODE_FILE, JSON.stringify(botMode, null, 2))
  } catch (e) {
    log.error(`could not save mode: ${e.message}`)
  }
}

// ─────────────────────────────────────────────────────────────
//  معالجة فشل فك التشفير (Session healing)
// ─────────────────────────────────────────────────────────────
const failures = new Map()
let healer = null
export function setHealer(fn) { healer = fn }

function noteDecryptFailure(sender, sock) {
  const user = getNumber(sender)
  if (!user) return
  // البوت الفرعي يصلح جلسته هو، وما يلمس جلسة البوت الأساسي
  if (sock?.isSubBot) {
    if (typeof sock.healSession !== 'function') return
    const now = Date.now()
    const key = `${sock.subbotNumber}|${user}`
    const list = (failures.get(key) || []).filter(t => now - t < 60_000)
    list.push(now)
    failures.set(key, list)
    if (list.length >= 3) {
      failures.delete(key)
      Promise.resolve(sock.healSession(user))
        .catch(e => log.error(`subbot session repair failed: ${e?.message || e}`))
    }
    return
  }
  if (!healer) return
  const now = Date.now()
  if (failures.size > 200) {
    for (const [k, v] of failures) {
      if (!v.some(t => now - t < 60_000)) failures.delete(k)
    }
  }
  const list = (failures.get(user) || []).filter(t => now - t < 60_000)
  list.push(now)
  failures.set(user, list)
  if (list.length >= 3) {
    failures.delete(user)
    Promise.resolve(healer(user, sock))
      .catch(e => log.error(`session repair failed: ${e?.message || e}`))
  }
}

// ─────────────────────────────────────────────────────────────
//  كولداون
// ─────────────────────────────────────────────────────────────
const cooldowns = new Map()
function onCooldown(scope) {
  const now = Date.now()
  if (cooldowns.size > 2000) {
    for (const [k, t] of cooldowns) {
      if (now - t > COOLDOWN_WINDOW) cooldowns.delete(k)
    }
  }
  if (now - (cooldowns.get(scope) || 0) < COOLDOWN_MS) return true
  cooldowns.set(scope, now)
  return false
}

// ─────────────────────────────────────────────────────────────
//  الأوامر المدمجة (Built-in)
// ─────────────────────────────────────────────────────────────
const BUILTIN = new Map()

function registerBuiltin(names, description, run, devOnly = true, category = 'المطورين') {
  const entry = { names, description, run, devOnly, category }
  for (const n of names) BUILTIN.set(normalizeCommand(n), entry)
}

function resolveTarget(mek, args, numberIndex = 1) {
  const ci = getContextInfo(mek.message)
  const mentioned = ci?.mentionedJid?.[0]
  const quoted = ci?.participant
  if (mentioned) return mentioned
  if (quoted) return quoted
  const n = String(args[numberIndex] || '').replace(/\D/g, '')
  return n ? `${n}@s.whatsapp.net` : ''
}

const rankByLevel = Object.freeze({
  '1': 'owners',
  '2': 'elite',
  '3': 'developers',
})

function rankLevelName(level) {
  return ({ '1': 'أونر', '2': 'نخبة', '3': 'مطور' })[level] || null
}

async function assignRankCommand(c) {
  if (!(await isOwnerForCommand(c))) {
    return c.reply(ui.deny('إدارة الرتب متاحة للمالك الثابت فقط'))
  }

  const action = normalizeCommand(c.args[0] || '')
  const listing = ['عرض', 'قائمه', 'قائمة', 'list'].includes(action)
  const removing = ['حذف', 'ازاله', 'إزالة', 'remove'].includes(action)
  const level = String(c.args[listing || removing ? 1 : 0] || '').trim()
  const rankKey = rankByLevel[level]

  if (listing) {
    if (level === '0' || normalizeCommand(level) === 'مالك') {
      const entries = listRank('owner').owner || []
      const rows = entries.length
        ? entries.map((jid, i) => `${i + 1}. ${getNumber(jid) || jid}`)
        : ['لا توجد حسابات مالك ثابتة']
      return c.reply(ui.box('قائمة المالك الثابت', rows))
    }
    if (!rankKey) {
      return c.reply(ui.warn(`حدد الفئة: ${c.prefix}اونر عرض 1 أو 2 أو 3 أو مالك`))
    }
    const entries = listRank(rankKey).stored || []
    const label = rankLevelName(level)
    const rows = entries.length
      ? entries.map((jid, i) => `${i + 1}. ${getNumber(jid) || jid}`)
      : ['لا يوجد أعضاء في هذه الرتبة حالياً']
    return c.reply(ui.box(`قائمة رتبة ${label}`, rows))
  }

  if (removing) {
    if (level === '0' || normalizeCommand(level) === 'مالك') {
      return c.reply(ui.deny('رتبة المالك ثابتة ولا يمكن إزالتها بالأوامر'))
    }
    if (!rankKey) {
      return c.reply(ui.warn(`حدد الفئة: ${c.prefix}اونر حذف 1 أو 2 أو 3`))
    }
    const target = resolveTarget(c.mek, c.args, 2)
    if (!target) {
      return c.reply(ui.warn(`رد على الشخص أو منشنه أو استخدم: ${c.prefix}اونر حذف ${level} 201234567890`))
    }
    const result = await removeRank(c.sock, rankKey, target)
    if (result.ok) return c.reply(ui.ok(`تمت إزالة رتبة ${rankLevelName(level)} من ${getNumber(result.jid)}`))
    const reasons = {
      invalid: 'رقم أو هوية غير صالحة',
      protected: 'لا يمكن إزالة رتبة المالك الثابت أو حساب البوت',
      not_found: 'هذا الشخص ليس ضمن هذه الرتبة',
    }
    return c.reply(ui.err(reasons[result.reason] || 'تعذر إزالة الرتبة'))
  }

  if (!rankKey) {
    return c.reply(ui.box('إدارة الرتب', [
      'تعيين رتبة: رد أو منشن أو اكتب الرقم بعد المستوى',
      `${c.prefix}اونر 1 201234567890 — أونر`,
      `${c.prefix}اونر 2 201234567890 — نخبة`,
      `${c.prefix}اونر 3 201234567890 — مطور`,
      `${c.prefix}اونر عرض 1 — عرض الأونر`,
      `${c.prefix}اونر عرض 2 — عرض النخبة`,
      `${c.prefix}اونر عرض 3 — عرض المطورين`,
      `${c.prefix}اونر عرض مالك — عرض المالك الثابت`,
      `${c.prefix}اونر حذف 1 — إزالة رتبة أونر`,
      'رتبة المالك ثابتة ولا تُمنح أو تُزال بالأوامر',
    ]))
  }

  const target = resolveTarget(c.mek, c.args, 1)
  if (!target) {
    return c.reply(ui.warn(`حدد الشخص بالرد أو المنشن أو استخدم: ${c.prefix}اونر ${level} 201234567890`))
  }

  const result = await addRank(c.sock, rankKey, target)
  if (result.ok) return c.reply(ui.ok(`تم تعيين رتبة ${result.rank} بنجاح`))

  const reasons = {
    invalid: 'رقم أو هوية غير صالحة',
    protected: 'هذا الحساب مالك ثابت أو حساب البوت، ولا يمكن تغيير رتبته',
    full: 'وصلت القائمة إلى الحد الأقصى',
    invalid_rank: 'مستوى غير صالح',
  }
  return c.reply(ui.err(reasons[result.reason] || 'تعذر تعيين الرتبة'))
}

async function isOwnerForCommand(c) {
  // صلاحية هذا الأمر تُحسم من نتيجة الفحص التي جُمعت للرسالة نفسها.
  return Boolean(c.owner)
}

registerBuiltin(['اونر'], 'تعيين الرتب 1 أونر / 2 نخبة / 3 مطور', assignRankCommand)

registerBuiltin(['مود'], 'تغيير وضع التشغيل عام/خاص', async c => {
  const a = normalizeCommand(c.args[0] || '')
  if (['خاص', 'on'].includes(a)) botMode.selfOnly = true
  else if (['عام', 'off'].includes(a)) botMode.selfOnly = false
  else {
    return c.reply(ui.box('وضع التشغيل', [
      `الحالي: ${botMode.selfOnly ? 'خاص 🔒' : 'عام 🌍'}`,
      `${c.prefix}مود خاص — للمطورين والجنود فقط`,
      `${c.prefix}مود عام — للجميع`,
    ]))
  }
  saveMode()
  return c.reply(ui.ok(
    botMode.selfOnly
      ? 'الوضع الآن: خاص 🔒 (مطورين وجنود فقط)'
      : 'الوضع الآن: عام 🌍 (للجميع)',
  ))
})

registerBuiltin(['ريلود', 'reload'], 'إعادة تحميل الأوامر', async c => {
  const s = await loadPlugins(true)
  return c.reply(ui.ok(
    `تم تحميل ${s?.plugins ?? 0} أمر من ${s?.files ?? 0} ملف` +
    (s?.failed ? ` (${s.failed} فشل)` : ''),
  ))
})

// ─────────────────────────────────────────────────────────────
//  نظام تحميل الإضافات (Plugins)
// ─────────────────────────────────────────────────────────────
let commands = new Map()       // alias → plugin
let commandFiles = new Map()   // alias → file path
let pluginList = []            // [{ plugin, file, aliases, rawAliases }]
const pluginCache = new Map()  // file path → { sig, plugin }
let pluginsLoaded = false
let loadingPromise = null
let reloadQueued = false
let lastSnapshot = ''

function getPluginFiles(dir) {
  try {
    return fs.readdirSync(dir)
      .filter(f => f.endsWith('.js') && !f.startsWith('.') && !f.startsWith('_'))
      .sort((a, b) => a.localeCompare(b))
      .map(f => path.join(dir, f))
  } catch (e) {
    log.error(`cannot read ${dir}: ${e.message}`)
    return []
  }
}

function folderSnapshot() {
  const parts = []
  for (const f of getPluginFiles(PLUGIN_DIR)) {
    try {
      const st = fs.statSync(f)
      parts.push(`${path.basename(f)}:${st.mtimeMs}:${st.size}`)
    } catch { /* ignored */ }
  }
  return parts.join('|')
}

const isValidPlugin = p =>
  Boolean(p && p.command && (typeof p.handler === 'function' || typeof p.run === 'function'))

function stripPrefix(name, prefixes) {
  const s = String(name ?? '').trim()
  const p = prefixes.find(pre => s.startsWith(pre) && s.length > pre.length)
  return p ? s.slice(p.length) : s
}

function extractAliases(plugin, prefixes) {
  const rawAliases = (Array.isArray(plugin.command) ? plugin.command : [plugin.command])
    .map(a => stripPrefix(a, prefixes))
    .filter(Boolean)
  return [...new Set(rawAliases.map(normalizeCommand).filter(Boolean))]
}

async function doLoadPlugins(force = false, announce = false) {
  const t0 = performance.now()
  lastSnapshot = folderSnapshot()

  const prevFiles = new Set(pluginList.map(p => p.file))
  const touched = new Set()
  const nextCommands = new Map()
  const nextFiles = new Map()
  const nextList = []
  const stats = { files: 0, plugins: 0, aliases: 0, skipped: 0, failed: 0, conflicts: 0 }

  if (!fs.existsSync(PLUGIN_DIR)) {
    log.warn('plugin folder is missing')
    commands = nextCommands
    commandFiles = nextFiles
    pluginList = nextList
    return stats
  }

  const files = getPluginFiles(PLUGIN_DIR)
  stats.files = files.length

  // حذف الملفات المحذوفة من الكاش
  const live = new Set(files)
  for (const k of [...pluginCache.keys()]) {
    if (!live.has(k)) pluginCache.delete(k)
  }

  const prefixes = getPrefixes()

  for (const file of files) {
    const label = path.relative(PLUGIN_DIR, file)
    try {
      const st = fs.statSync(file)
      const sig = `${st.mtimeMs}:${st.size}`
      let cached = pluginCache.get(file)
      let fresh = false

      if (force || !cached || cached.sig !== sig) {
        const mod = await import(`${pathToFileURL(file).href}?update=${Date.now()}`)
        cached = { sig, plugin: mod.default ?? null }
        pluginCache.set(file, cached)
        fresh = true
        touched.add(label)
      }

      const plugin = cached.plugin
      if (!isValidPlugin(plugin)) {
        stats.skipped++
        if (fresh) log.warn(`skipped ${label}: missing command or handler`)
        continue
      }

      const aliases = extractAliases(plugin, prefixes)
      if (!aliases.length) { stats.skipped++; continue }

      plugin.category = plugin.category || 'عام'

      const registered = []
      for (const alias of aliases) {
        if (BUILTIN.has(alias)) {
          stats.conflicts++
          log.warn(`"${alias}" in ${label} clashes with a built-in command, built-in wins`)
          continue
        }
        const existing = nextFiles.get(alias)
        if (existing && existing !== file) {
          stats.conflicts++
          log.warn(`"${alias}" is defined in both ${label} and ${path.relative(PLUGIN_DIR, existing)}, first one wins`)
          continue
        }
        nextCommands.set(alias, plugin)
        nextFiles.set(alias, file)
        registered.push(alias)
      }

      if (!registered.length) { stats.skipped++; continue }

      stats.plugins++
      stats.aliases += registered.length
      nextList.push({ plugin, file: label, aliases: registered, rawAliases: plugin.command })
    } catch (err) {
      stats.failed++
      log.error(`failed to load ${label}: ${err.message}`)

      // احتياطي: استخدم النسخة القديمة من الكاش إن وُجدت
      const old = pluginCache.get(file)?.plugin
      const st = fs.statSync(file, { throwIfNoEntry: false })
      if (st) {
        pluginCache.set(file, {
          sig: `${st.mtimeMs}:${st.size}`,
          plugin: isValidPlugin(old) ? old : null,
        })
      }
      if (isValidPlugin(old)) {
        const names = (Array.isArray(old.command) ? old.command : [old.command])
          .map(a => normalizeCommand(String(a ?? '').replace(/^[^\p{L}\p{N}]+/u, '')))
          .filter(Boolean)
        const kept = names.filter(n => !BUILTIN.has(n) && !nextFiles.has(n))
        kept.forEach(n => { nextCommands.set(n, old); nextFiles.set(n, file) })
        if (kept.length) {
          nextList.push({ plugin: old, file: label, aliases: kept, rawAliases: kept })
        }
      }
    }
  }

  commands = nextCommands
  commandFiles = nextFiles
  pluginList = nextList

  const nowFiles = new Set(nextList.map(p => p.file))
  const added = [...nowFiles].filter(f => !prevFiles.has(f))
  const removed = [...prevFiles].filter(f => !nowFiles.has(f))
  const updated = [...touched].filter(f => prevFiles.has(f) && nowFiles.has(f))
  stats.ms = performance.now() - t0

  if (announce) {
    log.plugins(stats.plugins, fmtMs(stats.ms))
  } else if (added.length || removed.length || updated.length) {
    log.reloaded({
      added, removed, updated,
      total: stats.plugins,
      ms: fmtMs(stats.ms),
    })
  }

  return stats
}

export function loadPlugins(force = false, announce = false) {
  if (loadingPromise) {
    reloadQueued = true
    return loadingPromise
  }
  loadingPromise = (async () => {
    try {
      let stats
      do {
        reloadQueued = false
        stats = await doLoadPlugins(force, announce)
      } while (reloadQueued)
      return stats
    } catch (err) {
      log.error(`plugin loader: ${err.message}`)
    } finally {
      pluginsLoaded = true
      loadingPromise = null
      watchPlugins()
    }
  })()
  return loadingPromise
}

// ─────────────────────────────────────────────────────────────
//  مراقبة مجلد الإضافات
// ─────────────────────────────────────────────────────────────
let watcher = null
let reloadTimer = null
let pollTimer = null

async function refreshIfChanged() {
  if (folderSnapshot() !== lastSnapshot) await loadPlugins()
}

function scheduleReload() {
  clearTimeout(reloadTimer)
  reloadTimer = setTimeout(() => loadPlugins(), RELOAD_DEBOUNCE_MS)
  reloadTimer.unref?.()
}

function watchPlugins() {
  if (!pollTimer) {
    pollTimer = setInterval(() => refreshIfChanged().catch(() => {}), FOLDER_POLL_MS)
    pollTimer.unref()
  }
  if (watcher || !fs.existsSync(PLUGIN_DIR)) return
  try {
    watcher = fs.watch(PLUGIN_DIR, (_e, f) => {
      if (f && !String(f).endsWith('.js')) return
      scheduleReload()
    })
    watcher.on('error', e => {
      log.error(`plugin watcher: ${e.message}`)
      try { watcher.close() } catch { /* ignored */ }
      watcher = null
      setTimeout(watchPlugins, 1000).unref()
    })
  } catch (e) {
    log.error(`cannot watch plugin folder: ${e.message}`)
  }
}

// ─────────────────────────────────────────────────────────────
//  قائمة الأوامر
// ─────────────────────────────────────────────────────────────
export function getCommandsList() {
  const list = pluginList.map(({ plugin, file, aliases, rawAliases }) => ({
    command: rawAliases[0] || aliases[0],
    aliases: rawAliases.length ? rawAliases : aliases,
    category: plugin.category || 'عام',
    dev: plugin.dev === true || plugin.developerOnly === true || plugin.ownerOnly === true,
    soldier: plugin.soldier === true,
    description: plugin.description || plugin.desc || '',
    hidden: plugin.hidden === true,
    file,
    builtin: false,
  }))

  for (const e of new Set(BUILTIN.values())) {
    list.push({
      command: e.names[0],
      aliases: e.names,
      category: e.category || 'المطورين',
      dev: e.devOnly,
      soldier: false,
      description: e.description,
      file: 'handler.js',
      builtin: true,
    })
  }

  return list
}

// ─────────────────────────────────────────────────────────────
//  تنفيذ الأوامر
// ─────────────────────────────────────────────────────────────
function logCommand(name, sender, isGroup, ms, sock) {
  // سجل الأوامر للبوت الأساسي فقط (البوتات الفرعية ما تظهر في الترمينال)
  if (sock?.isSubBot) return
  log.command({
    name,
    user: getNumber(sender) || sender,
    chat: isGroup ? 'group' : 'private',
    ms: fmtMs(ms),
  })
}

/** يحاول اكتشاف البادئة إذا كانت ملتصقة بنهاية النص (خطأ كتابي شائع) */
function detectTrailingPrefix(body, prefixes, known) {
  for (const p of prefixes) {
    if (body.length > p.length && body.endsWith(p)) {
      const cand = body.slice(0, -p.length).trim()
      if (cand && known(cand.split(/\s+/)[0])) return p
    }
  }
  return null
}

async function runBuiltinCommand(builtin, ctx) {
  const { commandTyped, sender, isGroup, reply } = ctx
  const t0 = performance.now()
  try {
    await builtin.run({
      sock: ctx.sock,
      mek: ctx.mek,
      from: ctx.from,
      args: ctx.args,
      q: ctx.q,
      dev: ctx.dev,
      owner: ctx.owner,
      sender,
      prefix: ctx.prefix,
      reply,
      name: commandTyped,
      isGroup,
      ui,
      Button,
      ButtonV2,
    })
    logCommand(commandTyped, sender, isGroup, performance.now() - t0, ctx.sock)
  } catch (err) {
    log.error(`command "${commandTyped}" failed: ${err.message}`)
    // نص الخطأ التقني للمطورين فقط (نفس سلوك أوامر الإضافات)
    await reply(ui.err(`حصل خطأ في الأمر${ctx.dev ? `\n│ ${err.message}` : ''}`)).catch(() => {})
  }
}

async function runPluginCommand(plugin, ctx) {
  const { commandTyped, sender, isGroup, reply, dev } = ctx
  const pluginFile = commandFiles.get(ctx.command)

  const buildContext = () => ({
    from: ctx.from,
    args: ctx.args,
    q: ctx.q,
    prefix: ctx.prefix,
    body: ctx.body,
    text: ctx.q,
    sender,
    isGroup,
    reply,
    command: commandTyped.toLowerCase(),
    cmd: ctx.command,
    commandName: pluginList.find(p => p.plugin === plugin)?.aliases[0] || ctx.command,
    isDev: dev,
    isSoldier: ctx.soldier,
    isOwner: ctx.owner,
    owner: ctx.owner,
    developer: dev,
    pushName: ctx.mek.pushName || '',
    config,
    reloadPlugins: loadPlugins,
    getCommandsList,
    pluginDir: pluginFile ? path.dirname(pluginFile) : PLUGIN_DIR,
    ui,
    Toolkit,
    Button,
    ButtonV2,
    Carousel,
    AIRich,
  })

  const t0 = performance.now()
  try {
    if (typeof plugin.handler === 'function') {
      await plugin.handler(ctx.sock, ctx.mek, buildContext())
    } else {
      await plugin.run({ ...buildContext(), sock: ctx.sock, m: ctx.mek, jid: ctx.from })
    }
    logCommand(commandTyped, sender, isGroup, performance.now() - t0, ctx.sock)
  } catch (err) {
    log.error(`command "${commandTyped}" failed: ${err.message}`)
    try {
      await reply(
        ui.err(
          `حصل خطأ أثناء تنفيذ الأمر ${commandTyped}` +
          (dev ? `\n│ ${err.message}` : ''),
        ),
      )
    } catch (sendErr) {
      log.error(`could not send error reply: ${sendErr.message}`)
    }
  }
}

// ─────────────────────────────────────────────────────────────
//  المعالج الرئيسي
// ─────────────────────────────────────────────────────────────
/**
 * يمرّر أحداث القروبات للإضافات اللي تعرّف onGroupEvent(event, data, { sock }).
 * event = 'groups.upsert' | 'groups.update' | 'group-participants.update'
 */
export async function dispatchGroupEvent(sock, event, data) {
  if (sock?.isDestroyed || !pluginsLoaded) return
  const done = new Set()
  for (const plugin of commands.values()) {
    if (done.has(plugin) || typeof plugin?.onGroupEvent !== 'function') continue
    done.add(plugin)
    try {
      await plugin.onGroupEvent(event, data, { sock })
    } catch (error) {
      log.error(`plugin onGroupEvent (${event}): ${error?.message || error}`)
    }
  }
}

export async function handleMessage(sock, mek) {
  try {
    if (!mek?.key) return
    if (sock?.isDestroyed) return

    const from = mek.key.remoteJid
    if (!from) return
    if (from === 'status@broadcast' || from.endsWith('@broadcast') || from.endsWith('@newsletter')) return

    const sender0 = mek.key.participant || mek.key.participantAlt || mek.key.remoteJidAlt || from

    // رسالة فك تشفير فاشلة
    if (!mek.message) {
      if (mek.messageStubType === 2 && !mek.key.fromMe) noteDecryptFailure(sender0, sock)
      return
    }

    // تخطي رسائل البوت
    if (mek.key.fromMe && isSentByBot(mek.key.id)) return

    // تجاهل الرسائل القديمة
    const ts = Number(mek.messageTimestamp?.low ?? mek.messageTimestamp ?? 0)
    if (ts && ts < STARTED_AT - 30) return

    // تجاهل المكرر (قبل أي await عشان ما يفلت تكرار متزامن)
    const botScope = sock.isSubBot ? `sub:${sock.subbotNumber || 'unknown'}` : 'main'
    if (seenBefore(botScope, `${from}|${mek.key.id}`)) return

    if (!pluginsLoaded) await loadPlugins(false, true)

    // فك اللف
    const unwrapped = unwrapMessage(mek.message)
    if (unwrapped && unwrapped !== mek.message) mek.message = unwrapped

    const isGroup = from.endsWith('@g.us')
    const senderJids = getSenderJids(sock, mek, isGroup)
    const sender = senderJids[0] || from

    const access = await getAccess(sock, senderJids)
    const owner = access.owner
    const dev = access.dev
    const soldier = access.soldier

    // استخراج النص / اختيار من قائمة
    const selectionId = extractSelectionId(mek.message)
    const isSelection = Boolean(selectionId)
    let body = String(selectionId || extractText(mek.message))
      .replace(INVISIBLE_START_RE, '')
      .trim()
    if (!body) return

    // ── تحديد البادئة ──
    const prefixes = getPrefixes()
    const known = w => {
      const n = normalizeCommand(w)
      return BUILTIN.has(n) || commands.has(n)
    }

    let prefix = matchPrefix(body)

    if (!prefix) {
      const trailing = detectTrailingPrefix(body, prefixes, known)
      if (trailing) {
        const cand = body.slice(0, -trailing.length).trim()
        prefix = trailing
        body = trailing + cand
      }
    }

    if (!prefix && (isSelection || (config.noPrefixInPrivate && !isGroup)) &&
        known(body.split(/\s+/)[0])) {
      prefix = prefixes[0]
      body = prefix + body
    }

    if (!prefix) return

    // ── استخراج الأمر ──
    const text = body.slice(prefix.length).trim()
    if (!text) return

    const firstWord = text.split(/\s+/)[0]
    const commandTyped = firstWord.replace(INVISIBLE_RE, '')
    const command = normalizeCommand(commandTyped)
    if (!command) return

    const q = text.slice(firstWord.length).trim()
    const args = q ? q.split(/\s+/) : []

    const reply = content =>
      sock.sendMessage(from, typeof content === 'string' ? { text: content } : content, { quoted: mek })

    // ── الأوامر المدمجة ──
    const builtin = BUILTIN.get(command)
    const plugin = builtin ? null : commands.get(command)
    // أي أمر معروف = البوت الفرعي مستخدم (لحذف الجلسات الخاملة 24 ساعة)
    if (builtin || plugin) sock.touchActivity?.()

    if (builtin) {
      if (builtin.devOnly && !dev) {
        return reply(ui.deny('الأمر ده للمطورين فقط'))
      }
      return runBuiltinCommand(builtin, {
        sock, mek, from, args, q, dev, owner, sender, prefix, reply,
        commandTyped, command, isGroup, body,
      })
    }

    // ── أوامر الإضافات ──
    if (!plugin) return
    if (!dev && onCooldown(`${botScope}|${from}|${sender}`)) return

    if (botMode.selfOnly && !soldier) {
      return reply(ui.deny('البوت في الوضع الخاص حالياً 🔒'))
    }

    const needDev = plugin.dev === true || plugin.developerOnly === true
    if (plugin.ownerOnly === true && !owner) {
      return reply(ui.deny('الأمر ده للمالك الثابت فقط'))
    }
    if (needDev && !dev) return reply(ui.deny('الأمر ده للرتب الإدارية فقط'))
    if (plugin.soldier === true && !soldier) {
      return reply(ui.deny('الأمر ده للجنود والمطورين فقط'))
    }

    return runPluginCommand(plugin, {
      sock, mek, from, args, q, dev, soldier, sender, prefix, reply,
      commandTyped, command, isGroup, body,
    })
  } catch (err) {
    log.error(`handler: ${err?.message || err}`)
  }
}

export default handleMessage