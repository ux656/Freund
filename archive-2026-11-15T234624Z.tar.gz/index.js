import { makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } from '@whiskeysockets/baileys'
import pino from 'pino'
import readline from 'readline'
import fs from 'fs'
import path from 'path'
import config from './BG/config.js'
import { log, silenceNoise } from './BG/BMG/logger.js'
import { handleMessage, setHealer, pruneCaches, dispatchGroupEvent } from './BG/handler.js'
import { createGroupCache, attachGroupEvents } from './BG/BMG/groupEvents.js'
import { cleanSessionDir, CLEAN_INTERVAL_MS } from './BG/BMG/sessionCleaner.js'
import { rememberSent, getStoredMessage } from './BG/BMG/msgStore.js'
import { startServer, setStatus, setParentSocket } from './BG/BMG/server.js'
import { startAllSubBots, stopAllSubBots, getSubBotStats } from './BG/subbots.js'

// ─────────────────────────────────────────────────────────────
//  الثوابت
// ─────────────────────────────────────────────────────────────

const SESSION_DIR = config.sessionDir || 'season'
const PHONE_ENV = (process.env.PHONE_NUMBER || '').replace(/\D/g, '')
const LOCK_FILE = '.bot.lock'
const LOCK_TTL = 25_000
const LOCK_HEARTBEAT = 10_000
const LOCK_WAIT_ATTEMPTS = 9
const LOCK_WAIT_INTERVAL = 5000
const HEAL_COOLDOWN = 5 * 60_000
const PAIRING_DELAY = 4000
const MAX_BACKOFF_ATTEMPTS = 5
const UPSERT_TYPES = new Set(['notify', 'append', 'replace'])

const sleep = ms => new Promise(r => setTimeout(r, ms))

// ─────────────────────────────────────────────────────────────
//  حالة العملية
// ─────────────────────────────────────────────────────────────

let currentSock = null
let reconnectTimer = null
let pairingRequested = false
let lastHeal = 0
let attempts = 0
let starting = false
let heartbeatTimer = null

// ─────────────────────────────────────────────────────────────
//  القفل (Lock)
// ─────────────────────────────────────────────────────────────

const readLock = () => {
  try { return JSON.parse(fs.readFileSync(LOCK_FILE, 'utf8')) } catch { return null }
}

const isLockFresh = (lock) =>
  lock && lock.pid !== process.pid && Date.now() - lock.t < LOCK_TTL

async function acquireLock() {
  for (let i = 0; i < LOCK_WAIT_ATTEMPTS; i++) {
    const lock = readLock()
    if (!isLockFresh(lock)) break

    if (i === 0) log.warn(`another instance is running (PID ${lock.pid}), waiting...`)
    if (i === LOCK_WAIT_ATTEMPTS - 1) {
      log.error('the other instance is still running, stop it and start again')
      process.exit(1)
    }
    await sleep(LOCK_WAIT_INTERVAL)
  }

  beatLock()
  heartbeatTimer = setInterval(beatLock, LOCK_HEARTBEAT)
  heartbeatTimer.unref()
}

function beatLock() {
  try {
    fs.writeFileSync(LOCK_FILE, JSON.stringify({ pid: process.pid, t: Date.now() }))
  } catch { /* ignored */ }
}

function releaseLock() {
  try {
    if (readLock()?.pid === process.pid) fs.unlinkSync(LOCK_FILE)
  } catch { /* ignored */ }
}

// ─────────────────────────────────────────────────────────────
//  حماية مجلد الجلسة
// ─────────────────────────────────────────────────────────────

function protectSessionFolder() {
  if (!fs.existsSync(SESSION_DIR)) {
    fs.mkdirSync(SESSION_DIR, { recursive: true })
    return
  }

  try {
    let removed = 0
    for (const f of fs.readdirSync(SESSION_DIR)) {
      const p = path.join(SESSION_DIR, f)
      const st = fs.statSync(p)
      if (st.isFile() && st.size === 0) {
        fs.unlinkSync(p)
        removed++
        log.warn(`removed empty session file: ${f}`)
      }
    }
    if (removed) log.info(`cleaned ${removed} empty session file(s)`)
  } catch (e) {
    log.error(`session folder check failed: ${e.message}`)
  }
}

// ─────────────────────────────────────────────────────────────
//  إدخال المستخدم
// ─────────────────────────────────────────────────────────────

const ask = q => new Promise(resolve => {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  rl.question(q, a => { rl.close(); resolve(a.trim()) })
})

// ─────────────────────────────────────────────────────────────
//  إصلاح الجلسة (Healing)
// ─────────────────────────────────────────────────────────────

setHealer(async (user, sock) => {
  if (Date.now() - lastHeal < HEAL_COOLDOWN) return
  lastHeal = Date.now()

  const files = fs.existsSync(SESSION_DIR) ? fs.readdirSync(SESSION_DIR) : []
  const bad = files.filter(f =>
    f.startsWith(`session-${user}.`) || f.startsWith(`session-${user}_`),
  )

  for (const f of bad) {
    try { fs.unlinkSync(path.join(SESSION_DIR, f)) } catch { /* ignored */ }
  }

  log.warn(`repaired ${bad.length} broken session file(s) for ${user}, reconnecting`)
  await startBot()
})

// ─────────────────────────────────────────────────────────────
//  الاتصال
// ─────────────────────────────────────────────────────────────

async function startBot() {
  if (starting) return currentSock
  starting = true
  try {
    return await connect()
  } finally {
    starting = false
  }
}

function computeReconnectDelay(code, attempt) {
  const base = config.connection?.reconnectDelay ?? 3000
  const max = config.connection?.maxReconnectDelay ?? 60_000

  if (code === DisconnectReason.restartRequired) return 500
  if (code === DisconnectReason.connectionReplaced) return 30_000

  const backoff = base * 2 ** Math.min(attempt, MAX_BACKOFF_ATTEMPTS)
  return Math.min(backoff, max)
}

function wireConnectionEvents(sock) {
  sock.ev.on('connection.update', update => {
    if (sock !== currentSock) return
    const { connection, lastDisconnect } = update

    if (connection === 'open') {
      const me = String(sock.user?.id || '').split(':')[0].split('@')[0]
      attempts = 0
      global.mainBotNumber = me || null
      setStatus('open', me || 'unknown')
      setParentSocket(sock)
      log.ok(`connected as ${me || 'unknown'}`)
      return
    }

    if (connection !== 'close') return

    const code = lastDisconnect?.error?.output?.statusCode
    currentSock = null
    setParentSocket(null)
    setStatus('reconnecting')

    if (code === DisconnectReason.loggedOut) {
      log.error(`logged out, delete "${SESSION_DIR}" folder and pair again`)
      process.exit(0)
    }

    const delay = computeReconnectDelay(code, attempts++)
    if (code === DisconnectReason.connectionReplaced) {
      log.warn('session opened elsewhere, retrying in 30s')
    } else {
      log.warn(`connection closed (code ${code ?? '?'}), reconnecting`)
    }

    if (config.connection?.autoReconnect !== false) {
      reconnectTimer = setTimeout(
        () => startBot().catch(e => log.error(`restart failed: ${e.message}`)),
        delay,
      )
      reconnectTimer.unref?.()
    }
  })
}

function wireMessageEvents(sock) {
  sock.ev.on('messages.upsert', ({ messages, type }) => {
    if (sock !== currentSock) return
    if (!UPSERT_TYPES.has(type)) return

    for (const m of messages || []) {
      handleMessage(sock, m).catch(err =>
        log.error(`message handling: ${err?.message || err}`),
      )
    }
  })
}

function wireCredsEvents(sock, saveCreds) {
  sock.ev.on('creds.update', async () => {
    try { await saveCreds() } catch (e) {
      log.error(`could not save credentials: ${e.message}`)
    }
  })
}

function wrapSendMessage(sock) {
  const rawSend = sock.sendMessage.bind(sock)
  sock.sendMessage = async (...args) => {
    const sent = await rawSend(...args)
    rememberSent(sent)
    return sent
  }
}

async function requestPairing(sock) {
  if (sock !== currentSock) {
    pairingRequested = false
    return
  }
  try {
    const number =
      PHONE_ENV ||
      (await ask('\x1b[96mPhone number with country code (e.g. 201234567890): \x1b[0m'))
        .replace(/\D/g, '')

    log.info('requesting pairing code...')
    const raw = await sock.requestPairingCode(number)
    const code = raw?.match(/.{1,4}/g)?.join('-') || raw
    log.pair(code)
  } catch (e) {
    pairingRequested = false
    log.error(`pairing request failed: ${e.message}`)
  }
}

async function connect() {
  clearTimeout(reconnectTimer)

  if (currentSock) {
    try { currentSock.end(undefined) } catch { /* ignored */ }
    currentSock = null
  }

  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR)
  const { version } = await fetchLatestBaileysVersion()
    .catch(() => ({ version: undefined }))

  log.info('connecting to WhatsApp...')

  const groupCache = createGroupCache()

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    auth: state,
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    getMessage: async key => getStoredMessage(key),
    cachedGroupMetadata: async jid => groupCache.get(jid),
    markOnlineOnConnect: false,
    syncFullHistory: false,
    generateHighQualityLinkPreview: false,
    keepAliveIntervalMs: 25_000,
    connectTimeoutMs: 60_000,
    defaultQueryTimeoutMs: 60_000,
    retryRequestDelayMs: 500,
    maxMsgRetryCount: 5,
  })
  currentSock = sock
  setParentSocket(sock)
  sock.isSubBot = false

  wrapSendMessage(sock)
  wireCredsEvents(sock, saveCreds)
  wireConnectionEvents(sock)
  wireMessageEvents(sock)
  attachGroupEvents(sock, groupCache, {
    label: 'main',
    dispatch: (event, data) => (sock === currentSock ? dispatchGroupEvent(sock, event, data) : undefined),
  })

  if (!sock.authState.creds.registered && !pairingRequested) {
    pairingRequested = true
    setTimeout(() => requestPairing(sock), PAIRING_DELAY).unref?.()
  }

  return sock
}

// ─────────────────────────────────────────────────────────────
//  إيقاف نظيف
// ─────────────────────────────────────────────────────────────

async function shutdown(signal) {
  log.info(`received ${signal}, shutting down...`)

  clearTimeout(reconnectTimer)
  if (heartbeatTimer) clearInterval(heartbeatTimer)

  try { currentSock?.end(undefined) } catch { /* ignored */ }
  currentSock = null
  await stopAllSubBots().catch(e => log.error(`subbot shutdown: ${e.message}`))

  releaseLock()
  process.exit(0)
}

process.on('exit', releaseLock)
process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))

process.on('unhandledRejection', err =>
  log.error(`unhandled rejection: ${err?.message || err}`))

process.on('uncaughtException', err => {
  log.error(`uncaught exception: ${err?.message || err}`)
  if (err?.stack) log.error(err.stack)
})

// ─────────────────────────────────────────────────────────────
//  الدخول
// ─────────────────────────────────────────────────────────────

async function main() {
  silenceNoise()
  log.banner('BMG-BOT')
  await acquireLock()
  protectSessionFolder()
  await startServer()

  // تنظيف دوري لجلسة البوت الأساسي (كل نصف ساعة): ملفات فاضية/تالفة/مؤقتة
  const cleanMain = () => cleanSessionDir(SESSION_DIR)
    .then(n => { if (n) log.info(`main session: cleaned ${n} useless file(s)`) })
    .catch(e => log.error(`main session cleanup: ${e.message}`))
    .finally(() => {
      pruneCaches()
      const mb = Math.round(process.memoryUsage().rss / 1048576)
      const { active, limit } = getSubBotStats()
      log.info(`memory: ${mb}MB RSS | subbots ${active}/${limit}`)
    })
  setInterval(cleanMain, CLEAN_INTERVAL_MS).unref()

  const mainSock = await startBot()
  startAllSubBots(mainSock).catch(error =>
    log.error(`subbot recovery failed: ${error.message}`),
  )
}

main().catch(err => {
  log.error(`fatal: ${err?.message || err}`)
  releaseLock()
  process.exit(1)
})